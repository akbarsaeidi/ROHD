module HDC_main_L #(parameter SIMD = 512, HDC_LEN = 1024, F_SIZE=620 , CLASS_NO = 32, PERM_EN =0)
(
    input logic Clk, 
    input logic Rst_n,
    input logic data_valid,
    input logic [31:0] instr,
    
    output [$clog2(CLASS_NO)-1:0] decision,
    output logic valid_decision
    
);

    localparam F_PARAM = $clog2(F_SIZE) ;
    localparam COUNT_PARAM = $clog2(HDC_LEN/SIMD);


    logic [6:0] Sn1;
    logic [6:0] Sn2;
    logic [2:0] b_vec1;
    logic [2:0] b_vec2;
    logic valid_str;

    assign Sn1 = instr[18:12];
    assign b_vec1 = instr[21:19];    
    assign Sn2 = instr[28:22];
    assign b_vec2 = instr[31:29];
    assign valid_str = data_valid && (instr[0+:7] == 7'b1111111) ;




    logic [SIMD-1: 0] HV_out1;
    logic out_valid1;
    logic [SIMD-1: 0] HV_out2;
    logic out_valid2;
    logic [COUNT_PARAM-1 : 0 ] counter_chunk;
    logic [ F_PARAM : 0] feature_counter;
    logic [ F_PARAM : 0] feature_counter_q;
    logic bundle_cond1;
    logic bundle_cond1_Q1;




    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n)
                counter_chunk <=0;
            
            else
                counter_chunk <= (bundle_cond1) ? counter_chunk +1 : counter_chunk ;

        end





    always_ff@(posedge Clk, negedge Rst_n)
        begin

        if(~Rst_n)
            feature_counter <=0;
        
        else if(valid_str)
            feature_counter <= (feature_counter == F_SIZE - 1) ? 0 : feature_counter + 1;


    end

   

    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n)
                bundle_cond1 <= 0;
            
            else
                bundle_cond1 <= (feature_counter == F_SIZE-1 && valid_str);


        end






    HV_gen2 #(SIMD, HDC_LEN) hv_g1
    (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .Sn(Sn2),
        .b_vec_sel(b_vec2),
        .data_valid(valid_str),
        .counter(counter_chunk),
        
        .HV_out(HV_out1),
        .out_valid(out_valid1)
    );
    



    Therm_unit #(SIMD, HDC_LEN) hv_g2
    (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .Sn(Sn1),
        // .b_vec_sel(b_vec2),
        .data_valid(valid_str),
        .counter(counter_chunk),

        .HV_out(HV_out2),
        .out_valid(out_valid2)
    );









    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n)
                bundle_cond1_Q1 <= 0;
            
            else
                bundle_cond1_Q1 <= bundle_cond1;

        end







///////////////////////////////////////////////////
////////////// BIND //////////////////////////////
//////////////////////////////////////////////////

logic [SIMD-1 : 0] bind_out;
logic bind_valid;


always_comb
    begin

        bind_out = HV_out1 ^ HV_out2 ;
        bind_valid = out_valid1 && out_valid2;

    end





    /////////////////////////////////////////////////////////////
    ///////////////////// PERMUTE //////////////////////////////
    ///////////////////////////////////////////////////////////

    generate

    logic perm_valid;
    logic [SIMD-1 : 0] perm_out;

        if(PERM_EN)

            begin


    logic out_valid3;
    logic out_valid4;
    logic [SIMD-1 : 0] HV_out3; 
    logic [SIMD-1 : 0] HV_out4; 
    logic [SIMD-1 : 0] temp_val;
    logic [F_PARAM : 0] shift;
    logic [COUNT_PARAM-1 : 0 ] counter_chunk_add;




    always_ff@(posedge Clk, negedge Rst_n)
        begin

        if(~Rst_n)
            feature_counter_q <=0;
        
        else
            feature_counter_q <= feature_counter;


        end


    assign shift = feature_counter_q;
    assign counter_chunk_add = counter_chunk +1;

    HV_gen2 #(SIMD, HDC_LEN) hv_g3
    (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .Sn(Sn1),
        .b_vec_sel(b_vec1),
        .data_valid(valid_str),
        .counter(counter_chunk_add),
        
        .HV_out(HV_out3),
        .out_valid(out_valid3)
    );
    



    HV_gen2 #(SIMD, HDC_LEN) hv_g4
    (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .Sn(Sn2),
        .b_vec_sel(b_vec2),
        .data_valid(valid_str),
        .counter(counter_chunk_add),

        .HV_out(HV_out4),
        .out_valid(out_valid4)
    );


    assign perm_out = ( (HV_out3 ^ HV_out4) << (SIMD - shift ) ) + (bind_out >> shift);
    assign perm_valid = out_valid4 && out_valid3;




            end


    else

        begin


            assign perm_out = bind_out;
            assign perm_valid = bind_valid;


        end



    

    endgenerate











//////////////////////////////////////////////////
///////////// BUNDLE  ///////////////////////////
//////////////////////////////////////////////////

logic [F_PARAM -1 :0] buffer_bundle [SIMD];
logic [SIMD-1: 0] bundle_out;
logic bundle_valid;





always_ff@(posedge Clk, negedge Rst_n)
    begin

        for(int i=0; i<SIMD; ++i)
        if(~Rst_n)
            
                buffer_bundle[i] <= 0;

        else if(bundle_valid)

                buffer_bundle[i] <= (perm_valid && perm_out[i] ) ? 1 : 0;   
                
        else

                buffer_bundle[i] <= (perm_valid && perm_out[i]) ? buffer_bundle[i] + 1 : buffer_bundle[i];   

    end




always_ff@(posedge Clk, negedge Rst_n)
    begin

        if(~Rst_n)
            bundle_valid <=0;
        
        else
            bundle_valid <= perm_valid & bundle_cond1;

    end


localparam Threshold = F_SIZE/2;

always_comb
    begin

    for(int i =0; i<SIMD ; ++i)
        if(bundle_valid)
            bundle_out[i] = buffer_bundle[i] > Threshold;

        else
            bundle_out = 0;

    end








// ////////////////////////////////////////////////
// //////////// CLASS UNIT  //////////////////////
// ///////////////////////////////////////////////

logic [SIMD-1 : 0 ] op1_q;


always_ff@(posedge Clk, negedge Rst_n)
    begin

        if(~Rst_n)
            begin

                op1_q <= 0;

            end

        else if(bundle_valid)
            op1_q <= bundle_out;

    end




    class_unit #(SIMD, HDC_LEN, CLASS_NO) clas(
        .Clk(Clk),
        .Rst_n(Rst_n),
        .op1(op1_q),
        .op2_valid(bundle_valid),
        .HV_SIZE(HDC_LEN),
        
        .decision(decision),
        .valid_decision(valid_decision)
    );







    
endmodule