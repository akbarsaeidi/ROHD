// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.1 (win64) Build 6140274 Thu May 22 00:12:29 MDT 2025
// Date        : Thu May 14 14:43:03 2026
// Host        : DSA-P46140-A running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode funcsim -rename_top decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix -prefix
//               decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_ blk_mem_gen_0_sim_netlist.v
// Design      : blk_mem_gen_0
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7a200tfbg676-2
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CHECK_LICENSE_TYPE = "blk_mem_gen_0,blk_mem_gen_v8_4_11,{}" *) (* downgradeipidentifiedwarnings = "yes" *) (* x_core_info = "blk_mem_gen_v8_4_11,Vivado 2025.1" *) 
(* NotValidForBitStream *)
module decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix
   (clka,
    ena,
    addra,
    douta);
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA CLK" *) (* x_interface_mode = "slave BRAM_PORTA" *) (* x_interface_parameter = "XIL_INTERFACENAME BRAM_PORTA, MEM_ADDRESS_MODE BYTE_ADDRESS, MEM_SIZE 8192, MEM_WIDTH 32, MEM_ECC NONE, MASTER_TYPE OTHER, READ_LATENCY 1" *) input clka;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA EN" *) input ena;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA ADDR" *) input [9:0]addra;
  (* x_interface_info = "xilinx.com:interface:bram:1.0 BRAM_PORTA DOUT" *) output [31:0]douta;

  wire [9:0]addra;
  wire clka;
  wire [31:0]douta;
  wire ena;
  wire NLW_U0_dbiterr_UNCONNECTED;
  wire NLW_U0_rsta_busy_UNCONNECTED;
  wire NLW_U0_rstb_busy_UNCONNECTED;
  wire NLW_U0_s_axi_arready_UNCONNECTED;
  wire NLW_U0_s_axi_awready_UNCONNECTED;
  wire NLW_U0_s_axi_bvalid_UNCONNECTED;
  wire NLW_U0_s_axi_dbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_rlast_UNCONNECTED;
  wire NLW_U0_s_axi_rvalid_UNCONNECTED;
  wire NLW_U0_s_axi_sbiterr_UNCONNECTED;
  wire NLW_U0_s_axi_wready_UNCONNECTED;
  wire NLW_U0_sbiterr_UNCONNECTED;
  wire [31:0]NLW_U0_doutb_UNCONNECTED;
  wire [9:0]NLW_U0_rdaddrecc_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_bid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_bresp_UNCONNECTED;
  wire [9:0]NLW_U0_s_axi_rdaddrecc_UNCONNECTED;
  wire [31:0]NLW_U0_s_axi_rdata_UNCONNECTED;
  wire [3:0]NLW_U0_s_axi_rid_UNCONNECTED;
  wire [1:0]NLW_U0_s_axi_rresp_UNCONNECTED;

  (* C_ADDRA_WIDTH = "10" *) 
  (* C_ADDRB_WIDTH = "10" *) 
  (* C_ALGORITHM = "1" *) 
  (* C_AXI_ID_WIDTH = "4" *) 
  (* C_AXI_SLAVE_TYPE = "0" *) 
  (* C_AXI_TYPE = "1" *) 
  (* C_BYTE_SIZE = "9" *) 
  (* C_COMMON_CLK = "0" *) 
  (* C_COUNT_18K_BRAM = "0" *) 
  (* C_COUNT_36K_BRAM = "1" *) 
  (* C_CTRL_ECC_ALGO = "NONE" *) 
  (* C_DEFAULT_DATA = "0" *) 
  (* C_DISABLE_WARN_BHV_COLL = "0" *) 
  (* C_DISABLE_WARN_BHV_RANGE = "1" *) 
  (* C_ELABORATION_DIR = "./" *) 
  (* C_ENABLE_32BIT_ADDRESS = "0" *) 
  (* C_EN_DEEPSLEEP_PIN = "0" *) 
  (* C_EN_ECC_PIPE = "0" *) 
  (* C_EN_RDADDRA_CHG = "0" *) 
  (* C_EN_RDADDRB_CHG = "0" *) 
  (* C_EN_SAFETY_CKT = "0" *) 
  (* C_EN_SHUTDOWN_PIN = "0" *) 
  (* C_EN_SLEEP_PIN = "0" *) 
  (* C_EST_POWER_SUMMARY = "Estimated Power for IP     :     2.622 mW" *) 
  (* C_FAMILY = "artix7" *) 
  (* C_HAS_AXI_ID = "0" *) 
  (* C_HAS_ENA = "1" *) 
  (* C_HAS_ENB = "0" *) 
  (* C_HAS_INJECTERR = "0" *) 
  (* C_HAS_MEM_OUTPUT_REGS_A = "1" *) 
  (* C_HAS_MEM_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_A = "0" *) 
  (* C_HAS_MUX_OUTPUT_REGS_B = "0" *) 
  (* C_HAS_REGCEA = "0" *) 
  (* C_HAS_REGCEB = "0" *) 
  (* C_HAS_RSTA = "0" *) 
  (* C_HAS_RSTB = "0" *) 
  (* C_HAS_SOFTECC_INPUT_REGS_A = "0" *) 
  (* C_HAS_SOFTECC_OUTPUT_REGS_B = "0" *) 
  (* C_INITA_VAL = "0" *) 
  (* C_INITB_VAL = "0" *) 
  (* C_INIT_FILE = "blk_mem_gen_0.mem" *) 
  (* C_INIT_FILE_NAME = "blk_mem_gen_0.mif" *) 
  (* C_INTERFACE_TYPE = "0" *) 
  (* C_LOAD_INIT_FILE = "1" *) 
  (* C_MEM_TYPE = "3" *) 
  (* C_MUX_PIPELINE_STAGES = "0" *) 
  (* C_PRIM_TYPE = "1" *) 
  (* C_READ_DEPTH_A = "1024" *) 
  (* C_READ_DEPTH_B = "1024" *) 
  (* C_READ_LATENCY_A = "1" *) 
  (* C_READ_LATENCY_B = "1" *) 
  (* C_READ_WIDTH_A = "32" *) 
  (* C_READ_WIDTH_B = "32" *) 
  (* C_RSTRAM_A = "0" *) 
  (* C_RSTRAM_B = "0" *) 
  (* C_RST_PRIORITY_A = "CE" *) 
  (* C_RST_PRIORITY_B = "CE" *) 
  (* C_SIM_COLLISION_CHECK = "ALL" *) 
  (* C_USE_BRAM_BLOCK = "0" *) 
  (* C_USE_BYTE_WEA = "0" *) 
  (* C_USE_BYTE_WEB = "0" *) 
  (* C_USE_DEFAULT_DATA = "0" *) 
  (* C_USE_ECC = "0" *) 
  (* C_USE_SOFTECC = "0" *) 
  (* C_USE_URAM = "0" *) 
  (* C_WEA_WIDTH = "1" *) 
  (* C_WEB_WIDTH = "1" *) 
  (* C_WRITE_DEPTH_A = "1024" *) 
  (* C_WRITE_DEPTH_B = "1024" *) 
  (* C_WRITE_MODE_A = "WRITE_FIRST" *) 
  (* C_WRITE_MODE_B = "WRITE_FIRST" *) 
  (* C_WRITE_WIDTH_A = "32" *) 
  (* C_WRITE_WIDTH_B = "32" *) 
  (* C_XDEVICEFAMILY = "artix7" *) 
  (* downgradeipidentifiedwarnings = "yes" *) 
  (* is_du_within_envelope = "true" *) 
  decalper_eb_ot_sdeen_pot_pi_dehcac_xnilix_blk_mem_gen_v8_4_11 U0
       (.addra(addra),
        .addrb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .clka(clka),
        .clkb(1'b0),
        .dbiterr(NLW_U0_dbiterr_UNCONNECTED),
        .deepsleep(1'b0),
        .dina({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .dinb({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .douta(douta),
        .doutb(NLW_U0_doutb_UNCONNECTED[31:0]),
        .eccpipece(1'b0),
        .ena(ena),
        .enb(1'b0),
        .injectdbiterr(1'b0),
        .injectsbiterr(1'b0),
        .rdaddrecc(NLW_U0_rdaddrecc_UNCONNECTED[9:0]),
        .regcea(1'b1),
        .regceb(1'b1),
        .rsta(1'b0),
        .rsta_busy(NLW_U0_rsta_busy_UNCONNECTED),
        .rstb(1'b0),
        .rstb_busy(NLW_U0_rstb_busy_UNCONNECTED),
        .s_aclk(1'b0),
        .s_aresetn(1'b0),
        .s_axi_araddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arburst({1'b0,1'b0}),
        .s_axi_arid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_arready(NLW_U0_s_axi_arready_UNCONNECTED),
        .s_axi_arsize({1'b0,1'b0,1'b0}),
        .s_axi_arvalid(1'b0),
        .s_axi_awaddr({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awburst({1'b0,1'b0}),
        .s_axi_awid({1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awlen({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_awready(NLW_U0_s_axi_awready_UNCONNECTED),
        .s_axi_awsize({1'b0,1'b0,1'b0}),
        .s_axi_awvalid(1'b0),
        .s_axi_bid(NLW_U0_s_axi_bid_UNCONNECTED[3:0]),
        .s_axi_bready(1'b0),
        .s_axi_bresp(NLW_U0_s_axi_bresp_UNCONNECTED[1:0]),
        .s_axi_bvalid(NLW_U0_s_axi_bvalid_UNCONNECTED),
        .s_axi_dbiterr(NLW_U0_s_axi_dbiterr_UNCONNECTED),
        .s_axi_injectdbiterr(1'b0),
        .s_axi_injectsbiterr(1'b0),
        .s_axi_rdaddrecc(NLW_U0_s_axi_rdaddrecc_UNCONNECTED[9:0]),
        .s_axi_rdata(NLW_U0_s_axi_rdata_UNCONNECTED[31:0]),
        .s_axi_rid(NLW_U0_s_axi_rid_UNCONNECTED[3:0]),
        .s_axi_rlast(NLW_U0_s_axi_rlast_UNCONNECTED),
        .s_axi_rready(1'b0),
        .s_axi_rresp(NLW_U0_s_axi_rresp_UNCONNECTED[1:0]),
        .s_axi_rvalid(NLW_U0_s_axi_rvalid_UNCONNECTED),
        .s_axi_sbiterr(NLW_U0_s_axi_sbiterr_UNCONNECTED),
        .s_axi_wdata({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .s_axi_wlast(1'b0),
        .s_axi_wready(NLW_U0_s_axi_wready_UNCONNECTED),
        .s_axi_wstrb(1'b0),
        .s_axi_wvalid(1'b0),
        .sbiterr(NLW_U0_sbiterr_UNCONNECTED),
        .shutdown(1'b0),
        .sleep(1'b0),
        .wea(1'b0),
        .web(1'b0));
endmodule
`pragma protect begin_protected
`pragma protect version = 1
`pragma protect encrypt_agent = "XILINX"
`pragma protect encrypt_agent_info = "Xilinx Encryption Tool 2025.1"
`pragma protect key_keyowner="Synopsys", key_keyname="SNPS-VCS-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
gydSV72FvW4hnoyUt6yZFJHfJqjRQWPUfYIuDKP0fpjrPOkLRbJGBr4Z9msYTvoIHRlYtXJ2YMY0
d1TIQb+FK4gKsTRru9wr397OxuFBsTRf4e+ZjpYZEdsnqYWcgMSzhN4yhPvO06GyZO15y/LKBxa8
3OKwxVlOLYXhv+sxdXg=

`pragma protect key_keyowner="Aldec", key_keyname="ALDEC15_001", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
WHB6Zbfa5Qi47krP9T4L8UnPOlr881dWx7UcYaZfNGIQQM0gadcoXbhucIpRaUuyOKxv6yhKveRN
h0l+N9+KX6rbZ6+TRhP9JAMuPhlpI7T42QtRv5zx9+m3ct5S0NMszbFaK8zeTAYra5BGP7BHmtkr
MpKfLK5sFyaTE/A7ACtAace9MwFTHDZdl9uUs4aY6KJlm6GaypKduiqkNugukJp5vlFPX/ZapJqG
KMtMhI6grhcuYb1FJrwRZ4jW7hs9HxddSdGLzsZ0HsBcO/qaCPTst+ZA0YIQfd5ULlFmPqq39FfO
p1P+2hEH2n+LycbMj5cn4Dxfqv2R8eucM78R3w==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VELOCE-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=128)
`pragma protect key_block
SmAzQA1VEuJXtJi5vXa2Jg7YvRqAJs6PX9HTZ1YqrJw4VfonBW3726gJ81BjlizpMkcf/Uk5sFIK
aPedVhEs4xCIZylz7gXYDshtytOA/pXUID2qV9nXr8qfI+FydSADUF3ScYDZmlkclFqlZrGq6DQ7
da3lJAzt2h/iR+cczrA=

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-VERIF-SIM-RSA-2", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
iAph5JWb/chMQpLPX1UoLjQDxN5l2I8McM/k2xN5wRht7HXoE6F5yV8luDjn3zkI6vnfUYo7BaI1
mogRRx+R3XcwxvhHr+lngh4+/YLVex1TFncl+kiUMAsu3M/FjFSiqGMVMdKTNLDqr35DuZJVyuiF
lTwXob/KkbQDJiJjBEoxbt+968rKRKRyJGcqIjm4mqRBdqMcgo3HOJFG74SFsWAQrxvXfBhdLSG3
OfoLfls9XDojBjp7G83k0h82g1eeWgBfydm/OcX9o48Pst93NvI4ua8WShZL8MCvRWYqWZrrjrWi
cfUjXAF5SDACjq1/OU6arz/Idz6/a7AP/jmexw==

`pragma protect key_keyowner="Real Intent", key_keyname="RI-RSA-KEY-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
BY49GZBxBT/gjZDPyaSWlti/sctckoR7jK6NuWdhnF9tiyNfVU7BqjjwxSnyMi0Uucv1BKHXC18h
8hQbFWnNtrq71ilURotXux7sssHlVJ2i1CsJWU18DOcBWxm2ai89uwvxDJh3TJkBJixB5KPvsDhL
lWOjTvZWPoR+Ixy+Tzo+U5Vx7z7SOakRwTrn3u7+c3vmCEBphE+HKeJExhBAoOEd0SXK5iwXaByW
D7Wb7zq6NNUmnCyaJ2BG9kGxLVsf+md7SlocuaFsYyaRZhwPyTucxIlz1tLYwcytKzx0ovoax3no
nYgzlzP/F0/PDWk9BqXgr/tuclc4EZYX0cf4ng==

`pragma protect key_keyowner="Xilinx", key_keyname="xilinxt_2025.1-2029.x", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
qGnCvL35qO7cbUEKCL50yDv1UvezcqBz601zctKop1954QlcjemzZWZHg1zJ00nJaToNdH2S8AKX
n8hNJvbQ+x5HEGL5DoSU9m5qjXd8xxocnZ0yzuZX/dGCT8kDn3gWJR2Gz13pT+w2LQUno1fX+MsC
ehgwvjBBT6GeYjdxHi+aybQUP9AblSxX/z3vh857SGCPohEWvghOgORCHAe45YD+ZWnL62FLxMM2
c+Ozq/Au/Q4q1Yzlzcfv8Mnsvg7OqOeEamQHbuYOfdkJUuYqOwsskEWW348u7FXtsf8m7P3pZyyz
IWyTDAW4igGguMPLHfbtK/twZx8ScJQmOKzglg==

`pragma protect key_keyowner="Metrics Technologies Inc.", key_keyname="DSim", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Hz+6K8+wh5/fukU4ZWNDXGsq6hreSVCSPP67nA6kUz9Vpjy4TtTnOrrl1BWY0ivEC7Ldyw8VI60A
VO/WPlt409LdAZdMZGsEZ1JuTZ0m9LPcgu9CPCyoMECctmd8LHE+otY6etTmYABB9syY61rk2hrv
RgbcyT/HCK9TzWxSm+XMqvx2nvagCLkMDPh/JZv51fj2zcKaBPnxsz8rnDipaeo0fEyVRC3Y1F/V
U3RmXojBjIumPHSJkQ537dENJEIA0Ra65u8EM/+ItUn1bcryLcIbKy1xGadrHmHdHRUoRcAodO2C
B48bNVeL0VnGg8P9ACIB04lMNzn5p6A1tPOb4Q==

`pragma protect key_keyowner="Atrenta", key_keyname="ATR-SG-RSA-1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=384)
`pragma protect key_block
YDpb+UeT0rJ543Q8wCo2xSS3gpVAT+JoStgBlV5IMjJoUOWkiOPn691FGChmDi3BTq5NxC73KHHR
1galACCjeTGq6cv+0Zc2Ocm1oobdrnSPHp7TMDr5Zle8FX6WywJCiGdoWBODggZSlbOASIK/PVfY
cZM2z60M6RSvzsi3TnYHiKYHpju8THVoSgRd6r31GcbiSy9TjjARERXan0OVc79jGuAg90mmDEEq
91eqmn6NZ9yLI2fgBjFUZbtFCpmJ8WGxOL1h39niWnRK3ZXnk8jcpnZUlxLbYTPO0Z3vVr1zrvcn
RVQloU0OLqg7M95zSs7NtX5Vzvb6jGbMehWV+WMMyxWmxL2XOwsAwPSeX2dI2r77pioY7X6VzH7f
/JxMAnq9udra3WGPsUkD1G0CvPkCC3zdxjpVaflY37ztX9UONhKtzMQa8lJc1IL8GhXRY3R9Lg2c
HIeXSGkpNNuFDqKT6Khe/6Casq+SjFJq+IH9IUtz6RUZTkbFb0Xhgm2P

`pragma protect key_keyowner="Cadence Design Systems.", key_keyname="CDS_RSA_KEY_VER_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
Q+63zFEYw/LeMgxa7g8g79GGvSyIKDKD8RvvC4DHDQuGObf6n9OGZX4e17v/E/+EDEwUhsWQHFDI
Lp/aH+6fNRmhu9BEWVjxq2WRrQSl4eQjfIaSOXu2dlYh3JjRJwiUp4LteVh8RFAf5t5sRQO4dRIK
x+h28yliSgibaWEAv5FaJQ1EFbNwmgedAaSYjgf2A3afBUcBh5Uy9VHbW/zRzdhhJdsVNBjZYcFy
CVLOcf1toCRp8J4U5FlnFMOzFegUbdXFQhq2VmIhPRxWjrfTk6iR4BcMEN9UMij/5IHRAeBdksyD
CqEKsyFxosbI5KVMRZ1Ln75Zipn0JdsGekHkxg==

`pragma protect key_keyowner="Synplicity", key_keyname="SYNP15_1", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
DPUa5DLPYRWvbPnX0U412yoWvvvHyuq43DrYmDJGTK0cR5U4U6th8icYgizC1/hUAEzt19kM/hVa
zZh7bXSWACYLpcfhPY8dRTVGDZVjpbkraw0ceBryLP7jc6Jt5JdNw88tZtZpprCB7nQ25lUL82Hf
WTwL1ZqgGIvtfHhxO0JF5L5ES5giedwQ6u5ffXG3UB6ELcpQD1NvpW5lAz4mfXyvVDCAPZN581TF
tlAy79iKbPKlJ2zFn1BS2cuRIHHe2JRxwPo+0n5VD5CXVgg+lCYxTnCxI8CdyFaTumbs4IfAKwVI
wSN/btbwDUhW9hAHWHIRo+BpdJ4qeGcTDPKtsA==

`pragma protect key_keyowner="Mentor Graphics Corporation", key_keyname="MGC-PREC-RSA", key_method="rsa"
`pragma protect encoding = (enctype="BASE64", line_length=76, bytes=256)
`pragma protect key_block
mf5hcf6JE6yLm0jNCQnHMVmogjLlPz6re0FwG67yvOJ3FuEorru0emIeAKEwgOoxjUYNWvcM7QAH
/UEeB2EIdjLl6glPAUda0HjtaCU2rdncVdM8k6DSMBggc4yo18Qx5F+1TD/RoBgoo0jNkMdDy6wJ
JHjqlN+R01z3yYIMQ9f2z6ZaYncbBYEp4+YAb7g1D7CSMxP5cFRpQznRpYp0JwqJfT9CHzlKgdab
8B288NxeLM66iYodiTS+GSRGLGtDWXpz9yeiuiPe6kJxae2GJyHIMSfluO/0Slc3m24DQNdbojf8
jdc0G2UnrDe5mCUTfYiDmpOWTUJOdYo0FK0N2g==

`pragma protect data_method = "AES128-CBC"
`pragma protect encoding = (enctype = "BASE64", line_length = 76, bytes = 27424)
`pragma protect data_block
esSfqVgDzWINc6j6/WGXtOWgHTPcxnQLpxtYAZJm0GEYjf3s3j4SH69PinQjXVGuIDjCxQALKww+
VwNnkIX6sEOnWpW5LETpRQNsGrOYPSKKDikjy7wKyqwwxOWqf2hf1/eD7ooGe3k0zZNdO2sYeonQ
lQwMEdt5oxqAkSgsq1CN2E350J3yY89iLJANmy4NBwVVnvxfw5Twa+i2kVxbRouI88lw7LXO+1hy
wIc52/7kfsfw5IdHdrKOOTJ/3xmlEdcwvhFbzay0lmuiSmRyG6XCxBBxQ19Ivc5Di6tas6ZniI7q
7XplFZUIhX1VWdNxIxfl0eR+OlDxI9uoWYahOZuI65teDNZc+Gc0osOOeJAvUgz42eQob4FV8CJt
kS0HwphKECRX+knfLH8VKDlM+kX3xPKVvFAnTFvxGrBiiUif5ZGa46VM3L0IPWOJHMPcpg3Nzc5U
yJSO/ZZ8Xv/lQPcJPE9zBh+3fdCF1952hSpmfRyAHWuJ93lJam3TSiDgXlyGp6JEuAxXK3Yp2Lg+
5JGh12SYJYephH1t0rJOqKULGkdngwr6D12WHzQ7CDoglIlwAJVTT3yQhoYwl8r2OIILPOOpPfr8
lVJ+UnNtTny7mK/RZqmbT+oxRCo+HyyeUrrX4oYscVBYYc/C0A/lpnhfvhkvBfMb1ust3W9YTSxd
LwmuIU33TtHSUlye7U/mVZUZDhU1hj3o40G9aijatOQF/hTJwHoakvehD7lOIaItcxA8/EpVKYlU
mkaiUT2DGKkIScOM7DxahLjwhnDFDfSIgAroorGI8yPskmvDUmDWc+Gmj8vW4PbjDgpZY90CHLHH
2ngidxZyi9VR8nILISQxMut9helRbhjRfs8kM3z50y5fpNeBhxzPrQHFFoptdjY8eKr7W1l/ASOq
VnzgruFGBWdzy+JZ2ZFqniz9WBDctGCwRqRuG9sWH6j6G3W6Y+rO0ynQTZMf1xIO/NVwGaEDV/7X
WFii8wz5qSMsfjGYJYuVOJ5hYRHyRBaGA92AU2tJZoLjZ3im+cglRl+eDN/0khflswDhaeZBTXxR
E0EZ5xktfurjZ8+J5GxAtiZ+WPLXaOAH/qAOOfdTs7BzYN0bkbpoXVvVuU0aW9UDasCoTUpVTgmc
YUpVdCzDYZ8aMjx2zqkzfA/WgKWRh9vkmmQhd5oRi1FMjvL1/6ECNB28L6s0uOedC+SR5m5DeIbM
Co2Iyp6RDYBuXWjS5cVwv2ndbceSfUcpM9V/MEbl21K+gZ5KohYzbJVchXmiC4zYxqOimrTrsMI1
lig5o83Oqoo/U4LbcyC2Ir5d874KdfntTkTp3ZZZiEe2iYZs/WYj3xcW5B74uHvf9Xp1sIfU1pv2
5YFNuFXJ07xs4E+ZEqLYHFqMdwAuf7zuUdZ1tqDpZRNjBVMZGgsKbyo2oOp/NVG4POPwOoKoJ2AY
DZnSbQa1ENeIMfYabtBCzvGbyIscDYUpB5e/LDe6pxDY8wBHNIjCI4/ZcqRakF2q1jH1gy4WnPiU
ozuWI8ZCdJY/taNEqsqqiaNI+2CETKzlU1J6gQXroC64UTX75LGhJdBHwaxYNfpE2anCCKxMoDKA
xW7PJZvOVJBHbqY2tNAZQd8hmlv3sGcC2Fgr+jpCcwZMRJZCZcfjmtNVg6BT2vGgj6V/fSi8jm05
YBgzbBBmBYVvFK9RAZj7d74y8ohFMEu819Be9rjEbJCT1/1C6w7ekT+iJBntqGTiMtTyROcW9tBw
XpCipfjWYuGwjJY4bT262vjGvuR38eiQFx6XElapGgLx37LhUgzx8O9+/39Hpdxw75pUWzQbDMUn
6OKKxTt/KT8hG4vzy7PNXOfXH+KBSta1d/U4m4s1IclQA3YgyJbtZDVAK7PzdUhGiGot67EzI3Uw
BdqY23O6XYnzcbHcfOGA9H+HNscu1jtfEe8n1eStmtE/9UBSJug2lD7/LFgQgBzU1+Jd0eWHUM+G
tQKLSsvWDpDZqb84u0JzqDvjFcOqonVWzC0AD0nmkOIHJiqYjKXKgXTEyVBALTbkR+J6UT2C2J5y
JK59MzVc3jZdnqLcMrwhsE6mkGAcGgz5oSDQTLMshanbA6dq31eqo+oZIeF8xN3/ZB5DAzFcgZEh
BarNhJlK7HlBaU9N/T6TzwyIZcsDby4XE7Bsdx5uhzHoKQx79jfJ8fDiBT/fNuGuTwsKcFH/ywpK
1ALXJkCChX0aE2GWKYsI6HAqEHhZYZ4k2ShHcndI3zUisE3ffZcxMSvUSSCTI3PvTljTGJaj3egn
3hNQpvU23F3eDfkCYtcb3h+a53QSYmeHkwM1SnJXfcOQF2WOcxnmzXbFqeXXRxQnPG8NEEFJqjHa
NVTptx3YlVKS5QqTKd8CRUZW7Xl0BkRT0MS5erMJJcHcozIpP1hhEMDO6X2Dgs/UdlWhkpIm5z67
Xj9gfVFKIDgl9eYTRunKOhdS6YbazcFPXnMSKFO7yyLW4tlLx7oVNHnsja28jNoFQt4JXws1nRWB
EmH54mgN4u5OCVM5Tc4GlV/f8b/oyZrxjTqO0dkipD5r4xDCCHd1fxvS83w/y8FiRg/jrRszFsfY
WGKpeRVJNfP6XY2wOWngeb5nUsLbGcSWupqb8Py2BPt8eNL8ElQRQX0tecdj8ux/4k9yYlsPtZcZ
7W1N8ebn4SMTMSbuoTMYrTKilEqWR1EhlmyyJIK2w6k/S/JEcB2q5xoX3ay5l4xMuH8IVErte9gW
J9ujJLES/VvANqIWDBpUeC9YuX1f8JlD4i37oywvZZxBBCnxWWASGlwjxDqE3//Tv3J7USGtTBiL
JLbxHzS6/vy+4OuRYfuJ3exo7dWdFl0ItjDvl/DeBZOCdATRRhhq8A5owPVsrKoVKbfptrhKUDP2
+OiEPKt/4CI4bPucveVzcRjaKGZrq5YJrkbbiLmU/DX5E4X5Lru0WT3XRum2JzIVluzXxeF1evxf
IjPWtSHvgNPQcVUUgqiNBHlMZmNnRs4oE2J6ftn5ka8TajUSC+KoQnfW31qprG4H480Z0QzOPs5g
QiOzRRhxk1as8cjhG7NwWTkQs8y1KJkkDNoMPv4PiURRi1lTQyojYUc79+V1Y85bFyr7dGLvHHxh
t6V6fTQelNobFmJ51rZ4HZw9hGXSKO5dV+bI28xOd9fvzyKvAIRl68sfnfZrUTYXLulcPBJ55qwo
Ri7mjEeok/d7KexJBM+iDHyMyVNQtrnI+VH18QqDC5hOFdAtlJ1UNPfOkHFV2oKJXDqrobqM252I
TwOzUADnZiiYZHqiDopEi9uyYZAMMo+vx5mguYM+Em4LzPUGqtetaQXhb+yJCM5Y8i/m8UmKy5vb
DOCZtj/iQeaGnyGrnKCgegEQBp9hlO9gW1ct3dJSBozWGCgWO4y5Y47coEdxI5DQp4LBTUiJ5wl1
+mAovzMeAqaPWs4QTnC7YL+jFnvTQw4eTcxcMlZl7s5uUu9Emt5tnhcjM33/jxzIySDQLRCyGWIP
suLVBCYvUrYt6jVhXFgBnwHmg/IaiI8t/RGtWF2Pvf+Ib2SUzcXay38WoFz/k1fnauueS9DTwN/d
uNK9cGTf8YIpTGALMD1uApdTKJCVNjqQPgMHpgcprMP+R3BTEQ4KfdqMJ5ns2o2Q5mRO6xiwPYZ2
ZbOA3wJ1j/jJPghXxFVA83ennGULrjC81qvya00tOUNW40W2GqnQ3W5VE9BsVz9K4HZDi3JZO/hZ
3XtjRcguXa5PPfSdJURLc+Hgv/uX9IFg6G1blAm1hyGUAd8lX0+PapQ9iebdwr/bo0em6ugV/PsD
8bcmUqyQAkFTkpVhHTuXDWtk6QmQgNmhret3JDjES8Q14Boeih45eF8G3JAQGg/QSW1gzCBwRznz
goUozfTcizJFeEM6Z8wdV58zVp4wqxPeHIPAxNhfEn1LxwfbXGpUuIalfauglzRNT8ejkw6QhI34
5YC0FoutsC3htQ//X0lCqSt1c5p/wyzvdMUfCsUGKCq/56FOyLCtHp4SM1SpjaZpyHYh291vXdsH
wfMqElAns5dZhAComyDpd3IWlcDoc1v8/gPmCZkz1kh66Y5yy2I03RNBzaXi+whlWKNO5zwf3/zy
0vzkjmJukElWGvv/+vtjeUuPkrWrKmFyX1xA8KA0CcPWrITcmvH+C9FF5MrtL4oP0cGtneObb1dK
CsdHvPx4hlK/EobSnEdF5Pmhj5xELOCmIQcgUNYSl0Tqm1VgVRqCvNa2X7rT2EwuCuNDQMgiW8Rc
WP1E1vD+AyCOj6annQIZDVdSDkTvS2nbUJ/RIgL3Ocpox/VNxVRz1kuZeQI7wdgD0VGTIxrTewm/
o/hkrMuuAVsSrWw8RDIJiaP/wG5IUy9vVbgnYZbjlX3oLOdEJOzO10ny86JpnWaqvab+nYL6fUw8
fd2OgRq8VW7yDkgQ/ivL87eDarTnzbNKI/Zi3cevIHzI49bjP/Js52xYlABLQ1scAI/Il2nayzCp
tnrp9fwDHLnxtuf2oqqQ2lQ4Dly+90VNPxaLKjLMTqlyoWGRa/RrAljncLzcW3OohIb7FPRukQTy
WEDWswg7j3nm3rDhsO5qFnhgobopgNG7YU1EAnipTXMIYfH0kGnZKJqWslCNmB4c927gmtLQeWA6
FpgVcPg6fJ9UW1Vixv0BF3JJCWwALzW+2Tdlb3KJuFK+RT7hem6TgS9AM9A3+nM4opL/Cl9TKm7Z
+rGEWMAGu6+bvK5sQ6GrmrS4QHdltpIQpanLFcb7ANHBOYUc5BSNQyk3kfxZdaUV++BRvk/8lJlY
6W4U7SoqlJpNp/OV1mT5D4v7ucrxsK/u8HFwRNbzHvWRZugvWphwXWNagmkCmYkTpL+XXBkoQqN6
oh4A7E1Ckuu+kYvUlEx5CqD+FR45HyiFjMhDj4cRMXvsRJVfZEpZsVq+fiJuZCQr0KnrlaP6G51t
M9EdPEO5HGGZxp9SgFpR0qhzUn0OfDBoDYaYB9fC14j7dPMhZuKFvJYYzNeNWLIg31QZptVtUcq1
+irgy8v66U2Ctu28aq+bvWpOwyVL7gc0yioncGOFqOjE1rsdkMxXlhvyANLy3LC+G0HcWsCDpQwR
j6KOoR6bNYJQzM/bQhHQcxDsjAtGCFMZZk3VCloIUrIbqIpWoCmcn+KPBsywFXLR30lFmAvNixxJ
76nrM+NSdeWv0jdDsz7cpmWhGLlcpryLs9K0HynI7FEbqnCd8oeJGq6S+7HTP+NbuG4Vr1y24M8t
i/TQzI29QOlQDUnYCgOIuETruX3cXkoSpZckV2j6c+AwYPDWt8VxMww+xhFqRQVBrkKK86es9KJE
odTSbfOLCE4JUBHbJg7xVjmgtD+TLn6iqHspHWzyyDnzOcU81AhXacnbhpf63GsvN+QWUVz7Kvrg
SAfkZVg+yP0qtVf5Z4i0tgBYCUyrHot609sTno/4dNaJOquR7f+lpmHlI4YBxSW3jOHqOGMaasKu
whfNAvs8C9228WwghVVliYbyYwo/VunYGW0Kfr3dL/CXQgH1EE4/Xkiv0471sj9eNiMmNsmDi7RI
+T1ZiN81JAKzSnBv/hLlVzQvL0nBxY5mVmP/ZS+3HEYXgKNFsa+Ehis4Xo7HK/vg+coI5VD5MCiC
jkzLRnQSObV1lFCCiKfzYa+LikpFNpLuiE1tXJt9XXQk0nj/DG+KLI4rs2tafp76t5OaVr+XHjpA
95HdPRDrKtM9c9Zb+dqKEVhqeK28daXASUestAjD9e2+6RkTMZwgrzoQ/JFhnLjdh1uBBmMgGy8n
zUQPISl7/7YN0OY+Na/+tvpCc/RIOBUBbYmbTeFACcFFnlG2Q5EUXtH4z/+fVjfzRiXWEOZ/hfQ8
4uAHLwZY9xlN39Xaw8GUS0FtxOkzelXURTbpBOXls4myc0mvbxsH4dc/eFVVC8QDX8mqB5lZS1cQ
ARdLVNB4VgKhxRjW4f9khVSb1vzyJTV0YA5Ug/F2jdVR6QatcNvTdp+B1tYMuXZg4Umcjii9GO45
D2JDeO+GvEdnuPnjhKnXmQftTwruz0qj7HyOqn/SzItakE3krC5t9wv9Jkq1Dk3u1AIBbDw+iVhV
ax5RiIgHWN+dCBTmSmItAvkvkOdVTlE0m2hX/d233rPMmdWgXHDKczUufRWAv0yFGefmI0uHwO2w
qoou46OoRBYbHP0lef2coLZunUVOmWkRzoAlPWTI5ue67mKP5AK1KuD+ht77YIXMdEIEHe9QBtp2
0sxj8ePKJwB10Fm5g8AhBZO8h12d+1MfygLeXQMUc46caldugWbwywKVvCHidGKSkYjnBiSM8wN3
9kd9GMLTOmy9tgbormScMKkRSHr0NxCBadUmzzynxfcZqEWfseR4WpHF2r64GXqij9YXI58K12HY
Fb7GbqkAyDewiK1OoKNSG7V1gPXP9/wi3ngQZg8iw2PV2WmEf+cwxFxWCjJ91OujNH7IvoWy4THU
e4iQZnSgMQBqk+AUePNIBdcQfYuFiiJuZ6xr5ZtXVaJ4ahwh2LEeEObmxPtgIoPteBKqP4UKIzPG
WwAk0i8Nd7+mAwaqsUCBdXL8b23Q60EUyHiUaDW2YZRnV6OUaZZlcr/nYp0RQZOUJLSiVUEN/KTT
Po4970Dtylv/8/Fj14Z1pIDy/zaaOg73ngna9h6UfqjnMppqzC1n9MRr+dRNodF5rwEwK0Mv1zg7
s3rpntCH5rcaY+1XL3fNVpgbkTJvanlIFl1xyJEYMiBPc4pfmTe8TjyY7SvOV38jvucLHV98YN6i
APUGAoHGyOnZfIDzgUiNHTIWRFBkQBxtSf3805cvIKd4tKWXhNoKe1Tdy1TBXcfKMBvojGdLMcXx
Vy0gEJO7Vdt43FaHEDIKtHbcAsxk3dPrMXT9wbtkmmSruNz7C0YI0RdelOhYQitNXJ9s3rbqm+2B
PKRwFdWfm/P0jJiNTBoyFiibvsRstertVnhMZorJ2bSSlIDBEsT1psvc2hgbDsT0SzTJCPED0k99
rhSuyp9wtjI7Y/uK0coJpPWihZ5wE7F0cAKh/ZgovMOUFSunS/kqoM/Fk8aXyFRN6RjQKjTdho7W
TRdANzv37czv1VuR/+u1jUZRIL7ixqUJ1JiLZ0z94ti/TZQ0EUFzWIu84LCXNdQmxErUfD7Uo7AV
cApWER9Fc+gIoqHZYDEebBbv9t4s0SuPUAJ2bjYOKHwnuiWHj3w3bo72wY7BMNnH6GLDL6htLb6B
ikKpp3BdqurrxSpq3ELA0VqXVFY4WFuSxnbwO+eTw3HtKNWgQVPSKF5byXrQdUbqR4x7RUQA+PfN
s4uTeDdbGq878752zrbc0f1fJgKxpiJXXWlzwPECwbUHGsPuBG7LUc+ZzJipVXaSO8eYeWEUJAAY
D932ZRgiy2bTZNOF8l7PDXNJpEhODBGQ2Oublt+pZuPWDai4STUngWdpvAFoqpJjlBDsol/8XbqI
wZw+CXENnG4BNrwYg7dn7SL3rbSRScgJqo2qvMWCzhEwnm13Jqoqhrl1isqWeRZ9fZI+tBwEg5MU
R4TOgixGAI1QzdXG0ewdtd1AHky1kaufjMao4zlai1C58I49pSqu3m4c54jlKQwY+rS9XjARLVwx
ELyfuI2oXEv5fA8rpys0XTllFJdY7GGURG1RumRI6YQCGPC0YWH56N7eBreX9fvWe+jBuDFi3XW8
DKMJjUGiRtHmd4ERh9pw57rC14DhkkxekvOTxNaUO3IpszSUxPRydnkxpfz6rM7y0PhyNmOITs4h
JsB+US/rOQVuaG3KK1kDKQxGJHf2rmqmA53yjmLyzCu/b89IPJ6uusTwPTtmSJtKil/Be2rBOpBu
gweoYk0gvVgACfU1x2Va/YAvnuaBbEQXEdvJZnWgrU/9tDavaT9xYx5YhydeyWqc6QQTWdmvbKw3
TQXs6ZVt3fLtEgp1UsFP4xHd0EK28/RcTME94vAzZzII7xnej4qvCguxOKWROXgPT83cKYeIrAa8
z5grWCA8Q27V9GZWGPou4cTKSCyc0AT5rMZbH5FXjXm/zNpO33k4WMX0iUA6Z9q7bB/M22NRk8/4
5MlyQkWalZnneD6XOTSYYbWZH5nFVJngt8IH6SuXXndKrHDhLy3M2mECTRhBJtwDTSr4mEamVVPz
p5Vc87dRMk1m6BPOIPls6LmKJJh8MB9JThSNRnPH+8ZoGnhGWh3C/eAiThNDMaqsYta6g9Mm6OKJ
+7Cu3xhvKzdXBpiVnfKJJiLZV38Kqjfnt1Zoq3Z2DNH1boAWHihQgk6AwxnOPce0V4rRxipe6HHv
0wd411YqYKmTpk5Ui9VyZ5DqIH6MBiYxEQdlhKft/d17oA0ju7IrKmwbKwuEpIGbudmN4GWcHks+
+Fsl0N83EnkcJXqqwbzOFhHWpm7wNEkkpFH7xPFYUXxYrJrQDI0XbOzBmmz1c1iImZdFd1azH9D8
aegWjhlpr+2i8rDAE1ivzi+olOgJwzY0F/NAAxYMKb96ovzOqqZx53q6Btgd97Kqhcr1YMM/Mt9j
YTQPtnp88nolzMsThFUIcdPyI2xN5xgmYjEv29Rxkw2V/MAu5p/eDeZ2g/KmijJjhZ1uaXvrH00N
1DceIXN9BCd/sY0McoVYDONnlg4QF1NDE0SVGxH+nuPf4Bp7mIvK3y8vFlXPDRdUBnsrx/WrymEp
CSlkgnWZEgp3/9QG9f5o/EwLTQf/qRu0h1O8FqES3lkIvLHy1+xolWBoLpuS00nGiDRaWIDh3yrX
JKag94TiCFfwjPYYOM1ihRJ+26CWwq4Pr/b5Rx+11xiWENn5tGc5RnPbpBQ8nt9912dv50t63hns
eVY/AjkaV75HNBxYrBcheuNpRr7XPEbtuT5m7jmwyI2F4Zi04F8T/BJjky6podZCiX2u0dqm76G9
SQSHn18JTx5Boe6NNaI79j3UT34t1gyQWDMdbqaoxvyfZ3kqpadkKjF4J4yOs4tBBglXgFrLm3UQ
1pXho6goF19D1N602Y0TcAZeWpL1wj3HMLww3D20tIXnO+/CLmVN/wr0SuNCNa1KFvnS8vLp27IK
vIJr8zkvQFuIpHdjTPDRmesV5nBpwKeUzLLeJedJGuTIKkmxKNow6fl6U8ygTUfzajbINRz3de3C
KlCsUG292qyfYGGC1U2hro312sIA5klWJxNiBdX+TQJfP4s7/RjD4+YDcA8g1yn1BpBDOR+PHvoq
e2jYWehZpHEAMsjt8fwmbzC7r5O+KztE4EnmvdUShKt3rRvWfd1GxqFHAy4k9dlpjdupvikwl2wz
tG2dpMSnXNxKKNgUuH+1xJYWNss0csEQgcfTdxRDrs56XYyKSRAQxOd/WjoFCpWHSka/YtSSgpBi
9o8/koFCEU/34idof3v3HpBHtquAeG8Wu8fZYiQzlIVha/TyGxwbVlL/oVuXYV/jP8jQ/A0Xp2OV
wg1XZAcsQ0Ks7HORkl+b7lp58fGssbByXQpJUYIYxejNjn32c91L23N/m+PCXdS7GRRWafp+s3+z
reEXkf1FzcQmDBnxn1ZpY+WaSURQ/qZfH1Gdem2X9QKVm9qcEx/5oEGnRtvV7C96Y8QGrlEiX5Tg
bqICNtHsZEBS2bSfvj5OJSFeWxqUJYssr/aJfx4932oqpoIj6Bey4UsL5NQKs+FtQvTAxZQD6gUQ
JHGi47m1JDkq584owdw75jtxHMbSn9O4vayJO9RsOsGQEwj0s3uKguEo/yBWmjYlxdjkC1Fn9tFB
ZMYtLtSCjbrKrfjeb18ucN2pVrapUtlF6VzcQVA0CZRHNBU0MwaPq9t9c3eQCMZ8NiP/mp7xKKZH
VZqFKSnlPveZgUIn+C/TYo6cB7IESDnzK6gis6vMU0pAb2E73AaswqH8oUDV2wGamxuCyIfEmrHU
hOBC5sZahgpS24SLzu213kMYdzbA8MewyL+Nw/PsbgucKfmiPL/bpqRVAokiKhBh9LBz630zfVdg
hb7V99AX/kvtfOUZal21sqNyJEg8VFLc0Co8W49X0Y6nflh37XE/K7vwochSxdelDWQoPyjVaYdH
UXz6H6mbNF9yKqqqUnEEvk/g/Y1qoL/R4qGafiATawArH7G9RwNuvjaLRv38nosV6peM7o1fPTOK
Cu0QwoTPxR7wveq9HCS5a3/fyq4nSsKaErHXRmDzIxmzusiE47v1lCh+7z2YbgJa+9UoUARpi/5B
fr4cTugqvP9jJ4eqFDLXR8iosTGyf0UYPVpGxSah+EV45oAfa4ojPsVLXl8tjSOEDO4fwNRaWCq4
PK4exQ3zP75y0YTVZpk3HgdOTkIwDe4Kx99R/eRrA9a3GuKm0KiLayUEmqJDxQ460/g6+JHZC1t1
0Kvm1JwRpKOIxzsmmSoFzfG8xh7x2pTDnGo40RidXyzL0F62elv/QiPtgXdYrfBE5iEQynoJL8L4
4KDc/7Fd2GRiLJFXgAd2pu7ehITW2NA35N1y5j8qoLLAIqfkUQqI/EFj/UsoKGMWZGEcUAZByUJ3
Hb/pTRzl2ieytX2OIgGpFv3ufAIADf6AVkY29QC7iHNt16Aeu9gwir+vzRCOyrtA5c/i9JcThaqJ
vp+GwY9OgXrOFwTOJwxNrKDPAiLQvHKvralDuKna0VLCTWekmwHi0jitDTY1Ygwzum3UOlCKBKHn
mlww4ZmtkPLBkQFoYDoYSwuD6ve1cfiw2ezAFHf8TJdwCRwfwe6NKrE1OXB/VDkHTE6N79IOQ9I0
YPo3oZHKlzI35P1a/IYMQpIuSGE4BFvD3NTJkiAOaTmvEZYQHwDIngxsVE+r/7m60tqTpq7X8p4b
TSDor/xfuoaudVN445ihBLNqKAhkzA2IQC1f8LGWufwSUHWgu2UbAEyn/SGfkh+sDJbK2pBp4Vsk
+AqK3nC++PF1HMyOKItuo/PpoQDEwX8RLG59vy7OZGH6OOiOz/rDATUXOofCYHocFbiOZKuZohv+
5jlmXspMMaLHQteMcFM7zm8kFwxdPG5RZu/ePfcz7YjlK8ak59G/zKS5kpghzHDbqIaJ/4R99vl0
fDOtP+oUS0NwSjEUy0x5yNv7rGFw26J2MwIpSXMwsW1Y62uYIZxg+/UxJqQoqThuZpDqIXtgIqy1
QGdkRunk9k/YrpdUs2zYI3jjP1qRJiLcB8X3l0pcHz8Isfa62/AoAdEe/I5sqlNnhlJZ9ZFUjz22
Zl9GNf0SM03JBMzFhFDazkLPxl/NbEwbLZVh3HVH+RFG8Z+iKcZIzBRpQLTrpkMOIfnq18fQB9I+
p09l2hd39/nrUNHacCBERRBvajyo/a1Rg+sntOwN+BUcwu+Zb5VCmFRDomlA1E6uxuUjqWeMOBu6
jITyr3+dAQtUt/cysIfIcqylwhpD9x6ZlgtkxChjXToWtYfE7+iqNiZ+xwHVEiVnNtbPZqMjKGOx
X5sLyIH48T3JT3qsyy1zYi3J8hM2ke6z8fmjdeRYoEOMnKtTFyBYArnA9A9B5smVfcJmDvM1tfIH
DBKC2AAAi+M4TCdIct1InTnRPOJ0+oA5ElqZYLHWpvrdnnBgHBA3HixCVEQl+oZC0fNH833Bm67/
i1oh3ecynjjpmda4O4hN91Z+gNJqeWAj4XU9l+nC/76Lzf3dfWWKCxdEg7uQ+9YLdWRgfCLBut54
i28HslhcinpDA9lvlq+J7cDZ76lgzi9pT7TCa2ekaKZdlTbBVpimY63lYxswPaF0JXpNmcK2gtWn
kJO5uYoxPlGnmS6qiirpJlZ9paBEQglA4M1lCOhzJID980PbixHpBwReIT7qDhEZimYqJq63q7hM
3lQCym8sEjNCUfodY8GpSWm46zZsW8n4ETd7EM0vNzceyDgjGjqHsNCLG0Pxk845xBWNYLetErXW
MOSgNIFOVA2qBztgEqSjeA/ELZTma6TOqMgszdLJVOtiIJrSl4nCa0kjO34BIdQmZgO8fZWuKql8
59wdSgj5PLeu4eiezrdLGSFDl2XjYrGccHOrtzWlPNqllAKQBt7IxB/47n1N232aQf1a3HkaEJPe
RkeF0gkU3ShaPwD2m3tNXJsODXoRb18IhYiVar+Aa5fuV2Bu+mSJ+VacatjNhR4D9Bo4Vi7x/B/5
pnoAOla/ZU6Bljmt3Sd87NZgxFapuhUh/RccF0X9LBROTQukJrOwU44cQZnLXjWXFUYYpxEmf7do
4moJp4Jl2I4fMTD0iTd91vDeLDchaJ0RVGYxPv+ceMVx3Ot9lYT+WReGjtvfF5gDRK66toOVFSD/
LbYWPTi83LYhCqjyeGJXFRzQ6OCmZwxDamgw9DGU+04nXIAQblga9LrItk/yG48k2rcJH8W+mIjC
uWOAGlSFayfnkbzq1JiL89nQXpP/5JqGWBT4qe0Di6/cDk3LsQCPOHPrb2mPzQf7sAmcdQ1aJMfS
DKqYZDNtXawnHD2fLyfAJOlenrCd31kjbr3y6TYFo8IuodJQr/HJ/93+5TOFbdk9oPFJ/Y1l146f
2X7wgLOThf9bCwT4x2gxUEmkDGaoyg1xuh+8ZiVwYTf63F/js7hXMZ8m64ArBOIwjipVzFnddhUQ
okdQiZARMLNI9QWRCETH046rXqlbo9gAc7TQGzIfoiRuNvMzEVir5BSkNDyF+P1EbDlbVpRCNV7O
LNyx6XAVS7ixne7jriAaPsFpDS4z/5hfMQ7XmdWY1LPK9lwyLtdbAPZjcjgl/AvoMAtc5noGQJV7
bZ8uJpLygeB9f28rhmoU7n6SCvrcoBoBlbmmDUnZ2+8PETF8s9jIy3rSLTOGL0R1wMAiTX/lIlT1
evDQtWShPfwPulprrTc55bUMmVRoz7yp2nI9zAnyrYqJEMcthKadTTqrPHQ79n3SWn9SWNM3K9zO
Y71NwFTQ/oawFSubV/lypRoEo4W5nOvFHsyRX73EW0wC5/g4ORvA0NIYnq/mJnoRZ65Rk7YytLXy
P/EVcrPDpW2nBwTU3MRdTImXCMmYxhhyR03h2XNJaoM3X4qHZ2dHQt9sfaKN5cHImsi09nI6iFxu
fKtcdBg2/RWt51NhXHR+E/wEO/nS1EcxJEN/qJ9tQ7ne6nPIAEhpAaYREZCU4Z7yoSeip7HIFeWc
RlEYeM6dI3Rxj2NveSiEMmhvlUbFuPsmrECFudg1eV/UDYxO6wuud4vHs/enLEXAxTolk0is1Cgn
bNZd7jCfjvKuOj18LMWRFUV8qrk5mJwI/+Ry+UdW6wKAc7AbtBueszi2P2lFwFGMh1rzeDtkjT0U
CF8LjreN85OkNAXzKWDKLd5ZxzrAfe4LVP5405eF4dWxor97T9vuG9kSJe/BalDf2V5Z8dm7EN2o
um6QaJxWO5K/yAyK0v/NZNUbWKELGBsYCT6naNZYFHAPG/xWg7qM7e3VlmVGyd0xoincupOFCtkp
aERldF8tM82nY7mQF7+Q8/zaq1XPuP0XRfDQehToh2/vtXBprqPuLbB9fgEgDDjfAZi0QOIeRi0G
O7GVXDxQtomnm19cEJ9zweMuE4381hr1yNAbas7UDbOkRdmJrIW4eyvNnLT5BqcGOoMQem32bWrr
YKOaRy86jk6xFQR8Zs6rtHKzT5tSORLa4XXFzqnHpjUy186FKJmkU+ryeCc2lKR66smGD4TrEmn/
dcVGLl+ssPKUxpXIz0qh5uIQXx6tCPUwTc4VIhcpczB69+45lOyOCIiY/Wht3pEBDADVcRwE9mJl
1kmPMhgs1ADAEhk3T/vENz23Fa834zQRgNaxy+MWyStT7gsPIIMmD72S+g5msqJG3V0t08axIsAq
0CU68/m07weWHQmHsg930cppBl/2tSxiOn2Ogcz7yj7wyx8glAYrtXFXqNKUl7foXHRRRi3NuSlR
BaZqBbJleD0M0gsmBRHti1KjFUUswNfhpHQUXQUO4lMuOGtpJtVNVMMnXFwdLuMhLTPXTSYmOOT8
QgXP7wSErl9rEXTjC1QC0AH9ynDw+ACLH8NKtL6GCwrUmROXz971A1OZeMkS/ijVXXwf/dJZlxVk
GBmvy/nzPxudyYfQNYZUVACHql1J5KG/Mk0asVzcnG8g/YOcXldW70wXQbCgQ8+7bQKA81vD0aYe
O20oUR8aS7k0QREcsNft2jsT9KUwTNIXGe8Cgxsorh8duaS13g7ORpOrC4yR71yMPq0Zmpfk/ahW
6iaAXVs40x+ZbQXdhpePhIr8xTup+QqgAcyJT1Fmt/TC0K6w7nhmi/xLIi1YvPxZtylFMG4UBvFP
ixaMOMdXI6nJ9MKrxAQcjp8hNO50+mI29OCfSJxN3ueR+vsitCkENC7p2M/j319xH4XT6Ri+Ll5y
+hLjjTHtVwXPddldklE/45HD3greyFice7gZR6M8c+VczD+An1QIJk8UCHeuhddSsyWZovS7vP5N
uZpNO36sE2qnZc+9J6A3be9plEJnw2VfvUz0DRei86+BjaUNrMUDFqlz3lgXKKYCUSge8xPv+98B
eA28D5y965UugJTXRytqn1CZMeAQMK6LfauQFVNMRLfT2YptcTaknobErSwOUuqm3QIpX5MpLiOS
9oQNTLDk0wtPwbfApE+Zjo3sYpnES8OVMwKONv5PbByeij3oGYrtiJIamEfzjvxebhoah0nypuC4
ME/14cJTMsmy1ZqS+GdPsEcr3oppu6j3g/BS+7/ARgj7d8x0a6SOpAU5xDGUzxs94KUaaeQv76lr
+5xo5nn53KifqHIl89Laz2AJyfig5+DRV67+CFn7HjwRJDOONe2ylMkn0xUTqx0PpW3RBslHJFmH
+wYac/Z7+qb2XpaA00kvkzR7bKxS/OjQywXp8mCUD8t3d8lmwbIprozkT9U2nR08n5WM4YFwlcbn
XyAIp6crvfDELJT76ddEFeByayTfACcRHhj6g+jl92J813IspthK5hYYbaJAhxNT+vGe3oVR4MDV
PcTmJ32wQcWpqw3blLYzQjpwgc3V8mgIrPDJxuxrFtL9e1g/EhlTdG8ntuZBcTwP/XG6YsW6O+LN
qPUbHpbU68P8gX8e3jC/IEIQkmYPOL3/uYTAACD+11A1ijB3GpMBH8IDURcPcVNqdTyqMeqAnKcQ
YbU0v8cmj7H+Rj4a6nvqU5khvJOazhSMmaiARRgKNzHWBVMidqPzMr+l4qDE+apNHTxmrbN3ImgL
kp3Eysr7DGtiE05fTxg+pUnOUXdlxuCGmqXH/fHio7k8ibA9Q12I+hdZZCWimu1zCpuVspe0DlOT
EJhV/KhJ7P06gurNSm+PCjI8rNRbb3Kwf6J973cmAN4/zWO9WbsxF6humuvjoFwfJX48ZX1PeltK
mFfdA1UI3pIt4fTsmZJEZyTY9m7DIZ7ONjYm/jkiP0KLvjtkcqQJ4HXuYzHeNFuk2Q0w23Gv5hKB
KAaOAzTns09lUhrTKzAIq6or6KWw5y0RnaogiaedCy5FwX4qGyp5pfaWAKGU3MBCH8mKEOynopjB
b0E2Nzs8jy28kJXtDezEDsBFAQlYiVuLTfGDul2PUBtvMth2YkbL184+yyKMkzeDPz1/4oOmOUBA
kyJZ9yI9bNzskXE80IfiwOdbCGLHluUaVqaXG8M54dSavSK13AzBq3Cr8ddbgvkF0bD0s3eJJRRF
MNq58jVy0TcMJJv1MSYhRirCs3wp+58ICdRPGUlW6RRupOURy0F2uA62ShJciyEZFsGI44Mz/Zsb
m8VshWSPotHPOKo7F1s9qTeegVx/oBYkFth8YawKQr7D75BmA1Z6XZhnqHfYjtbmHm0RtYcp+wrr
+my83wE7yMYwOgfiLLDXEfm8oypm9HGTC7Nf5qKVN/5G54HYQBbtbCxCE9192ATKlBi6SBbvFO3T
l5yRpXtOJJQesUYizdCQ9g+G0Bi85a6SvaabJmP7k07VnkdhNVObunRqLSjJ+GTLZGXoZyK6xF/a
4BgLosg/IcYZ+Vigz/yDDVbf7iqtIYY6c5DB84EMq3iGvwvAVitm2V8t+OhqxldcpqIUSYJ5Tj5N
a7W4sdPJDcG7FUOgw/OORYwm/yLk3TsKLGwt2O0naVz36wZZMGoWGeQX2GZys+ADSUqsqGzwP1Rd
jIbbnMbD3wgWrFDVoLCGItiFLFUAKxw/aA2oIVQ3eGxj3lXIU29KNwD9Jk4rD/0BEF+U2ZfVxK6d
mNmhU+e+dme1nBApw5mKQTS+Paog5TSQcu16BGbsrrqwOSv/iIGyFLTZAvBrdizp8btDKBbUgJFx
cvRzjooDwhxWIc37yn98dWSQXp7LqadBRYbDWYOVy288yt/feff2o98YhXPGZfyR/0NJ664OalGZ
XMFHJxSPwRucOMJPBUbJuU/SrTOKpPlXNOaVAL+OOLAocPEKsPRkIAfkkVT+5pmYthwQnEfUX4by
UQkuwgAmOiJf0QeOMBL+t5x2hLOXuZAMhSrVpNBxQsmW4CWBw+LRwGyDVY8uNp4VTcfBhc2L6PNI
QEYOXA4amdP3chRnJ6UpFGSohCbbfu8ZYAlhA14s60CwsTDltQXE4KhvNzt6l4Ro0jnhmVv+55h+
fhTnvUQrwUc80pQ70+g6jySw3uWL/2c8ViF89H5SclT+PCFyv0BwoORPg6tbk2KwMr3X6tdBTLEK
GA7ui8ycpZvkjQVpe9N3ZLl+P5cPRAXgiIMeyLcWE3kwh9lTJoJGul59Bq9oAmavvFSSN4KdFC8V
nA3dyN8fhaJ/VPMLAZZ1NKYgtgU9FJH9KA4P8wxRe1711FxBo5ZZo1JlskZDfxL6AOpGLjI246ac
ZM03DmG7XPP9TNTp41FQcjw2m0caIQmztKVJtufZ11lbYJ6kTy1R+lCIJp9ZCipQJZ6CGglk0xPx
ZvG9QMspXAnFKgDVi49/c/3SCDi4FXrop4XV3EhWfsrPBbXrQOrCQ+kevLoLAqGwdiqLl+VfYsPZ
P7KK+szQJszJAY33qUldlMHhodZQlKDiGrhzHCEHNYr3LFtP0aQYBsfLaxUBg+/qDTlp/DTN4oVk
ptqeuYFI1ss6Mm1hhmSacSE1t8lBPLf4PbqRrg5kRYVRqS50xFhdHyZoVmbA8OWbk575c6bK42WG
CDnX8WWAgJ4vM27nhXe8NF6TmAIDNknCvANDHGJbyQiA+811LuS1taS43cXDsUKjo2+dd7ZNc1qd
CVgW+8/R2XbAN0YrOXG5vIQgKoTPsDF/HABBJ3wwo26opl9jhDX5oDkdmAawlY/bCzFbUG1XTYyz
+VljHgj3sTozy7qpc/bC1I3iZmlUTwcymkMFkG765wUy6jcgpIrQPwoL+pSdx1z7aZArgnAabJ+W
MqRpVRPAEK+S4jJaUkUXqlu2GsqBF4g1YJOxFjKEYnFuqJo05svygEQLs9F6J/6lio4bw5vWcwoP
REki1jOej6niXvSXgq+hghnR/+xFJQXmo52INff3dgY3qQI6XbDy70Ce57CALcgba/NbDejdSuJD
T0LmZjUECgOM6e5MWT91d114bg3asceeii3bfoc+PnycYlmpoQj0aI4NIqB3OO48jBeQraV8CKYp
iNt0GxNiUQJzYGujOGBf5sBKmz9Ac4WUK+ub1TdkejLip63bVnCkNVw2aQOFcMGVyUNBDpZ6E6pv
frLsiAQ9uLZway1CTXAmDEJmXv/u+42PrApBjqYwsZBx2V8LllziOFzokIc0ZIEIxDqx5zrib3Mp
L1wigfS2xlJl4qICjGEBYIaS14JW7/IrTMB9Kwy7E5KCRcaR0FAbobcVHx5XJaI8gHSWbyLZD/sR
gGT9K+ArERfsGYTitG0gjbcnysDlGn1q6ulECwZOBAv99wsHIjs9WeQ6Z5DKcAveFxiiOmxseyMe
p62+4J3ZCayHNEzacjhUHMVVkOBH0UdLPCb/EK9OAPJngFNIEl3UB8iUyW54K87R4ohoFIiDwtNZ
NIij7JhR11vp7OGqpomt7Nor9yebjdhV3v0DQKUXSG8AUUussPeyzUisnA7QVgNwxFEVt5XNv11E
eiweLH7hkntOV+GfnfrLCqrhh0+pBuuI6fasjDo1SucmERFsqNJuID8t7tV7RHRnk2/JIx/Cw//f
kczCZQbvw7hHuau722IPOPyxWdZbsH0KfCp+h+IKFoaKJ1q4jA0OgUVpnmsA0vGn1O6K8sR/g+oe
6Kq4K9YicyHwakAenab2ZegKWki5q5mXdbor4eaxLxbPjla5XCACP7H3Hw1+iTcHW0FMf/znu6Qs
j7pkWFlpdIVE7Q1LHFCdee6PUATnENSEBpQ5rxIbF0Hatmm1uuz3AmS5qxlrIh1aoWjp29tQzOmb
OIxRlb8S1KIRbXoIMRaa9DdVEWJz8GMdymY5kUv8H49T9+3d6MfpvYtQZmDbAxbOvI3ZPlqEErH7
Sr8tvXDaAzk06ukcirAtLcktBwmMyUD4qZg5noW5+PXILARc4TRAbkTo8WisrWy3K1wWaO883DHV
4/p8RNv+722qA7qGugkmKKGT8kCvD8MnJdxGaYwhHV2mzc9+fxAXvOUZM+akJsMqcPSSV257c3nf
Rpf3Z66enYCA0aTu4KGqFFyspvckLyXLYNYeuBkxTLrcXFUghXTIm6vo2HV1YJbeeWZP34k9NEeV
vdwIGMEhWWLqLsFcjPssLS2TU9vAgT4n6hw6KuNiA8XCzabuk3otJYBFUoX2wblpNReUO9ro6Nd2
lTR5OQKOTbsq9Xn++BLfvc27gewY1jvUlJ9bgKEornq9ctS6UFf6O62Opi5RqrJn+n0J6B3qne5N
aPsTRfpYbjNwOqDooPKcMRnVuEox1Ps5CHFbbJIah++nfJwzhHiVTySY+9ITph3hMXDFQ4gAp5XB
BOPRVWmPjM1rn0p6xtJ87n7QgbnSzgk6fZa+Z9PJ5xE0cE0GoKs/witoKJ8LrAaGH6xrje7iU2xv
PNv4Cz1xeAHaZ3ZeVoqr68pH2YT7Hn28gaP2DgiMFZpZ4x1qvOFqBQg+wSp7acyM0s303Re920/Q
BzngLPP0L4zdRSwYjFanB5cjXy0uU2+6Jy3to6GRrfWSxQQd9QEV2g7bI4UtCPwZh7x9ATTQ6z0M
OFQ+St28Dc8uAvjLby8LnHx6VZ7csaQfbs1r8M4zc+kAKDUTw35j96eL6z5oxlb00ZcmGIdU5A6T
NUhTys+b4DG/ECzJqEmtbFSxnphgrU/jq0Ff8U/UPaaZVmXkpuzok+qh4ynUhnDvu53xXA456LmR
FbFNjPT0mWjjmuDsfN0nkCf2pT0mMuZFLlAZuinxJtvt7KGubpII1KbH0eOYg6BvyY8vPJsZxKxF
kklVTLbT/1O3aJ70aDdc7ZAY293r8G6fqDdd6hzISRlMt3TLVRn7XI4AlBOezslZmYft0uduircC
cEtWMSn1LAzbjjg72kQ7WU19OfP9uPvip8XJELnBLk3tzdX0qNXYSrVJ6+1vUK+bPxNLBvJRz2B3
PGU/05fpy5vlUd0yXv4dmrbLNyfLyMjyIvS/SxNhJMCdv28LomXHyw+gL1MNh4nTO2qaHhnBMwEl
qhGPKpU/U0p5h3HEI9Y/tGudebrWuBm5cxglP6yB3T/42AcTyVADSYL27KiUOoU+IwaPHTxb1thM
BVTZlouRXC4+rc+f6mbobjOGjPPIJIZ3qGluTYbe7Tde6u/HZSFfwEa8NGDVQF+qRtOI1aSA59lr
8RqK2IdbujP2pruME90H1G2ODMQdm8/6uj2g8ZUFQsryJmOmdb3mq5ixTjRMkB6YZAkrTy7uVlc1
dqqtkk7iPR1AOUIwqQ1M3pT0JGknoX98fOrmB9/lH6OFwTkXVu9NlfOoR+S6jHM8xKTn6Dg2rrTg
NqWmWPvxx2/hkV5untYuI5RnbO3Tl07+Xv9U3F9VG0Z/+rJvH+VY95WuE+MEEDSLbEfB3Dvr/HQn
63bRdrkVI4dcych02gYpbkQ5SbQwXS7uy6PDY4z3ZSAzCo9UvIhryqvjwUeyTeQdR8GSKa7bu8ku
LSpSouaPmRqRtP+UolqVavVncUg+JvFDwMmth/aDouBDUKNVkhisgIR31hDTf6IhxYuL81HV0IK5
gkSwVXE0J3b5fQLdggphlLSzbv0UIs8n6GZn8BMjL8H6knENITEEQDly4rz9jJnLWmS8idwWVfFR
VILOvkCHVoagY0muMmhRAVxBlhLu/Bu/6xunXwShLD434W4Z3V626CV/PiY2R001JPzPvKCkUJDw
FcbSIXf1FLYzt78B+jS9ZfzHXWcoMOv76hWXa0kZIXnD8HGL9H3ZFmRvz7U7p7k/FyH651UbGrdX
xiKYG1Zujj6ZJjofyGBc1ZaaenjtED7iEtuCHJintUSeXG23mYJ2xKruopJjbWZaAimOaLZeEL/h
0N4xFoVlmbz6JJtgPEJPBJ2aI75hTXyVm/bmNRfIEa/mDgSlv5FffwI8IByOxzIKqhCESLHugDUK
i/XbEX/fJ0EUwvDkj7gScKCGzLw6G1s2t5zuNoRwfJV+brRCg7Op9lU6to4uTqljVP0kN+gv1yla
mhs0pzlvshZ1HpgPuTWRHiZWpyt/NMfCSUjfvxkbRDsRUrflgVupFAAfMA4VBzhOQXHcUYRPpAih
ylAuA2Fu6GmRu2B5anTZ/vgCOOzjBbGmeU79X+0eRa7tjUWzIqR6JzpB0XvSgcpEHjM8rDV7P4rA
l2LAtbhLvXCZN4CDURZfwiPqpvJCjZL9PkKbDlIkJOdu+cQDok7J8XMr3zWj5LYL7t0TDHRH8I9i
cFgi6OI1CfdOf4UASqCwj8dvb/Ux35Gd+LuNFen1Fzg0ky1FHEZX9M5z9jh0MVTdkEW/qKOKF2wd
HHbj2SWg2tHFFN0JAS5tzt/RKA6EnVyFlTvwzhFayZIyMLzm1wPJWAOxyer7AXMfKVyLDeHUvaZQ
xTgmFB/WBP+0nw5ZkFj0mMyotacD14fjLEM07/Cz0Fr3OsgvR/QRk/6ItnqFxZw8E1V6EHNeOQAO
EDESI9Fzh+8ekOq4u4WT/VmVmEwZRvuE6jc3+cWqOLIr8JytIUecBzMxLsCCdejccOXxv0aata3O
jiqq8pOrsx2m6Gbn8Bbd58C/54atBplrm7ceUpzjGAqAz1QUFajlHdV2yD/aYGtlJIgT7Ioncj2U
3jWl6MZcvBurodyKzJhn6xwb5EYoCF83aYGIcbgukMxOyko8lXcfeVHX3vjRhSpll32dGhc+kAb7
pGrmcnZdRS0JE51ZtUB8nNBxlDvB+qnEWBbq/D7Lp5H/1WKzNuMOvp6i9d8Z4o2dQtzvxxLCeHCs
a2akNjDcDh47l7aG84nTtbYv6VEB0cLec7FkekBh1EYUptDUz/o7Gpp8hxRPZnVf+Lz2Qivd9Fy5
t0OP5FQ2/K+re9qVXb0t5qgEhSiQGO/Y3sIopT8a+RCDvge3pWRe9kjFI65v7j0h+LhF18fmi/AX
a6XbPlRyUnVy/DPMhaTamt5IX037b2c6EspfaU8WiMts3IaNtFxtdlLw9C9i5Nn8CoDZG+Yk9Vfk
EEdOwoHVxNO42OjofIorF+pikdh1vyw6nNBuYad9uJQRNTt9X9VTb0y+Ct/9NAqkkuq/Jrp+XGnT
9HCo1JI1HEAFyDdmJrUA+E8Z1MMcMwbXUmvPdnEn8ZQfwNnWCgu7d6c/5zo0gaZghOb2gqJsSPlM
KE9GIFZnDGnJtHoVV4p3p/6OGag20vvbq1ohMYmgdex60qRf7SjNJ4LUY1roJKD5oZZ6FGp12Dz/
CJj+nDqyOYSBpCIGRcXNEFUqDOnNHTJcDA2gNE00M9fCCPhVMUheh9HOwHriqXFE1qHKWlHxgSs+
rlSdJcej9vcJ/T+GPm2LN/vhNXzYvCoa/f9raQRYLes2dDKMa5Da6n73bNlXLTcly8Tk/lDE8E98
FAh9fqxEkN05vHFKb3D6hTRzfwHC73rMVq/pOIK132d+WG2coU7kNx6K7nVfAdoQ8Gn5xSuc8ydX
B7COixcJ0yAx2KMZpOA7rBN/2ugLcRayGkTYdzWD1wEy8sZmczwuzyjVsScF1LP5QPRgZBrugHMv
3PzNl0fUHDV2fZ8IfDytQ9G/PpI0BE/YkrYxv+bmqAoY5Gi1N9Qva+D6yLPW6DqbDErJCPpLMjq8
MSHf+Ms6Q7uNLJjmen9bfDIsecfGraOtXvPaVuB3hsb46K838BQha1i3v1EOFdBjv9grOtt4L+p/
bUgCyumgBAprOiShXr89UZZfxoFW/caVXiAwWVZACFeJl/C7lmqmsmVN7nmGnkwPnrud9Sb2aLHW
fHWiWvT2AVgAw98EC+Q558/MtMl0VjPXA7bIiL9a+xo1Ys+JR6A2NWvv3El2ZT2JfbkZh3vhdXg0
LKVm9/St3EHWB6jgL4hDvI12EzaTojsJvCLIKvbHZDc/hYBjkvBWBw5GePq4ZRdK2EHm0zODqysI
h3y/RzVAQaZTvnCdaaHGxm+vgT+a7s+iSjMoeDpG6duyDqtcpssuUZSI9buXeMolO0Rn6Q15IM3b
u0nYORM4V3bjgFrKEAE2to/S/+UJNX/jpflDaTDPPSo7VVYWzU4aI8HtLc0SUdTsjWaEEnaW33+Y
aiIfMUG8RmvYFei3yXd1rTsB0KuQl9niImJPvrv8Qpn+ZZwa7VNmlW8xV9Ha98qYbfISVsE36y6z
a79yy2IaNe2kXxGp9vfRbD4ECdNs3dobwui6tWwndEoJE+cHUdrQcFJ11bESjW5VYlapUneQQWMg
+6/7BY0xz+uKN2hFL5JduEU4Mm7WR8UxOLxyw3p7vNvCZ2BFpAxAlD3DDhLt6fvDFpK/YGCVATTc
cIL3uZULtvfdXX75Umny+e8oDUf0ucHqJFYjFKwIHfIDUoq/NihAduLIO4FLJbqHlgRztE9ipWSJ
6H7TCW5/0RLXEkcZhkU3wo8IKviJqX5fC4f8OP5AaGWZGllahnCIF2Fj1Mm2ocbNm985H3maYA7p
DB/Jgp5WEm4SoRHaaZCejeBL5n0NPNFYNU7/796WKivjhNVwbuKIobC3wpcbTZJYbz5mVzTi9mtS
O7d3S2/fJ1uFvq8u6zcPnnlnpR1jByxLbThcbEWKntCQSmK3gnjhjthHCOMIOoWeTJQY21jbygZT
SaGMAVBEMdwee6H/A2I8gWzoEk0GyLpCw6bdIc56LK3+n0YwwdSg/SudEBeyd52UXgHRFLhwKsfK
fvGfH+zoM3UYtZWiY3oQ9Xyfetjvsfq7ReARdqZn7yJADhW4YdBV7A697ecA50srHHDs1qatLwaE
LYr3d/awZ0GJH3NzbvVLLTnkcGk+nfnMTTG9TKblejdV+WedWDmIBx8wSckDegDxNZFNBhUxHCMe
vsOM44AelYOPwm59buTMOrENuPT6H87hXT/lWThgGAq9T6YMKhlCDlNvkljkl8HS8Yt7NrGrxE8I
+PNsSaO8KhafgxX3EeLVN0JWTdgONImgmWpffDyV66q0QsjCoBbw3t1q1Smb8Y+6VU7edg/kTuXt
H5Q0t4TnP42sMACA5vVA0a/kKTqJFXT4SU5hkbQ3TdbF7y6WBRS8f2qPEoqAfBaIi2mBLjVWHb/C
eD43LD2dnNOK3fGXlaQgGMiAJ99wLRZTF4/SskpGS7V2no1TMBSToBE3UIyJcmlblfKnhuOpPvY9
sDuQnVmiXQaM/eL67eA+tO8GS7sl/MmcXmn0ZmVPJXrgaF8iXNxR2BclE/ah/Ir5Li4pwiYK0Juj
vR9JCaNYTPokN3z3bJjLje2IYt3bLc4tkvzqFg37TUuQ9pVPz7+0BRl1CLcSDXyt73N5s1PsV77K
d3CIu4P2iXD/oCn/rFAfxnt03U3IfnReX5qd2RfS59omtXrAfLaepprDB3uOM0QcQwmePkTkxoJW
gPWpPNLxjw/hEjdxFXDRT2J6UC+q+jqgesHF1fnZOvldXZXx+09qZAqnZfoBb2JRiTGapoHP2u0w
+sKxdy45uEOWS9b1TbARGm6rVAsmkbsRC4UdljLgmgADvq46miWT6ZW5h770vWaOzQhZBUA4E/54
eNGfDROIKJSlBOIkAnLmYU7SlgCkCkgBzxgeyK2O2+07b16xVrSPDx5GYXkIBo46EYXK9JtX29y0
6AT5X3Z7Sy7KxNvA4wSFlTi9Tp+LbGH0pJ6cP7Bw+UexsHv5Dygvz2y3ms1C8tsVNxukGteSUppe
rdkwrlwfcPlhS2VjzIUq0eJqFzShp8WdKhJkpom5nuwOQLIev/b/TxvCp++Q1nE/wahPjihd67nK
0xQ9KCDXjww59tIsxI8GSm6XzqBTArG0QILZdMsqtlciWXdZbInpPNZunnGVEdRSXXgqxNKNpYMK
ZPiMIDR4GSbmXDmKx7o3CjTCsLvBaJaxA7vWHnR8QD9nqoFppcwHZENyyVnA6Pd5tsPOPovDGi2Q
waaFI9//nHJFwpRXgVcs0HQugfHdg+BG/Mzdui7vf5YbGZinh19p1IPtDznJYq54lXrwycTtslpz
r1SGXg3pkV6Ncfaexx5EFQuQ14JwJL1Ghhy9itInNXNHtKpzl9kYHcGZUAmCdwij5SvRS1H9l+o8
rYxgQRHxquT7XnAMaIpbK0egYSQGMw6cmwzHcMKqE2hKooJoQt8edz1gOkONMn1fmdRSMUcIr+V3
YF1dhHXNekOp1wh/z+md/cvXnkzPFirhuAH2P9vDlr/CBztXp2B6G3Y4WLbZki9gIxKfl0i8wwQ/
iKtdS25MNGqN+ZNk2neCqfLVj2vJ0YBgOEaUDm0Si4aBdXNbhGsjBOVRYi/ktOu8MXwNKIHVLycZ
ALoBd2ML/jg7GWJq3ADUDz2GZPCUgo7gOiPPWP3ZJuEQu5Cy323p6UkU5yklqRoi5UevfBtIXuvO
AnNWAAixO03+o95oqgOf3Qfwqu0COs3j7Ug6xNqCy4660Yw3K7x+i4MANobDBUkIcwFr1kJxRYwI
lBAkCS/Dxa3EfT5GyMpxvoft6hK1XPx8qK+eJ/nAYyXmaFCryQb7GBGlr0qle2LKoktHnsDRY5nO
gZ7LStHsGTAceVBl0xFtBu4GXh9GE5+7cgOfj+FlnvipRzRemDRulxsrmHGHA4I2dRSqqdJozIA7
UdkPFayrQjQpnir09gBZRnFXfNaZAfUNIhyhwiTShwOSv3Z9YsIOwg+4O2e9rFHQkFd1CigfknlX
/gd7oFOUyVqbWqlpX9jZMIM0XnAtKeKhgiz6JgWZv5gBCljjsKTYg+fcxsiZTrdduKdC4YYcTi4t
mm1gWzswwTmpNWs0T5fjJ5K1SzczzhmVz+XrYgoOY/4bFcgCvmTOry5dgqUlYnsWuZjGPzcpWuvw
pujsnLXYVz7BALUspe37aFr5t1KtXHrxIu4UpFxzbTeHC2mvRafeMQejfeIjHXDxZ8KWTYygjNWw
CHSHnKwCa0dwhChzYi0EErgi1WkbvMitxsnnn3K488ztnrQVtc2yrS40D4JfTmGjXf+NoupVfHtO
zN/F5n3yz5IyBBh2kRxIhEZquVXa2nq+0WhRYDy7/lpNoHwebuBYdwo5e4RGqVjIt8LZwEI8d/IM
qml86UEu8+o4aAH+J0Gbwo7XxMesjazay13XiEhwZUfhm2L43V8BV6AEJLFgOXSJjpg+0GJFWtuM
mkOEqmyes4vhm32x+hk/K1wdkacIwvk3pUKcd9/JIla89BJTigzizdotQvg9QwNvN2DFNl4I+9Bb
0Y0/CQerIjtLAxP4SNUC/z0Tc86IQZqQLEpaMQaJT9NG8yCmCRTy6haZpILaeOKbMn2KAIvV+D9C
OIMJAAdtbfL7y0X+iuYFEQ+0Go0ydLnJD8+u0WarB9MUibTC2nQky36GqEeHc05oI1RUtoxohWom
FNBblUpH3AuGsZyKVr0c9cSY3Y9fLASYaClGmBhzY5yNSpaSRZxH9PaUe1pLOPRJLlpaNGzL6+Ed
EFAwScV4RZLfk5n6moh5g2+hcsgvELm5KjhNN0pkoS8kKe6cO9WL7nu+yU5cXU0tT+jVfaaN7Mv7
nbfGpgXUXMF7zhIbTFgbpk5o8+dgzK4gF9GyrxHabHSZMMXGTPabP6ST5dZt2S3XMfo51C7b8CWp
X3lvSgxoey2ErltaJ9BN5nvfHjfgA9rT9/5j7ZCiEJY2gSUz0Y5R5xMHMtZC7gNIl5Li56Gg56JW
M1Wqm8VZPDGLmXy8K7xYOg1fP3XyQzadTPUj7PrNZ4GKZWA486kDX1NGhHaPAM/SE91xdJJyJpLr
7sA3uw5URFfPJFZZWD7qkS4XA9xz+cy6pPMWUyy8+TUwdz/JhtybDf6GTJlOiXrJbvxLrpXlK6N6
/k7fkvF1HLFKFuYkrylNMjygweMUKEbrQlHMw3hXfCUEmI+StE2B3y3X/1SkerjHTx9zS2fyyLuG
QKJ5QsIw3HeuFwc793aAaFzjlQn9PmMt25kB2V0v74J++XwgUn99DiAHZ9ilhvwJTP6uOXCLGl+4
XpMZ4rRjUhdmX5ZEsXbrXwIjKasPNQ7sIxiBmp54cBlb+kMGC0SjryU3cbB5OgfuCJ3j+YVx1fku
e5iMO6YX4L7KTPRlpVjpZti9SVt/NtlCRUSuWuPDpzVwMR6BYWVewTbuXZfV4ddv2A1VrqgEYKqS
DXMgnNyGifuCNoCRKSlWlFEN0JO29Vvxav0i64vYoAOUqWyrTOyz6Qi2ZRwyvE4GL30hdxM1HClk
WiHJZDXOHV6avmfvBxRQGUMSjAixMCSUdWSM/EG2JYE9IpjFB5XI4iRPOlaEruLu77leQG0f4Aj6
alWKw8yacbc+TZi3YmVCI/5Mv3qSgKq5BPjLEz9LTTAdWsvt3DH68Xxkp77aCqH4kHIkBq+jRchq
ES0BamzRrq/Ot1/+/hKlnSFCn6f0V9Sj252bJXFx62J7jqnzM1hk0g/GZaDrBjCcqWTzQ/S7eptJ
Jl9tYitG1ma3tOJ1v74b6J/iHq/kKdscjt3Xi0km+KI8QH+cVQL7hs04xYaqPQgcGrPUxNoEqyTf
1JW7+cS2C09c+5pTmCQOuAucCLPcPZFKiXeRUy0UrIAQonY/HfvpZmiO1mXVdacTsC/S9c2ywUiX
VlRnLvMQMPliPt3yj66h0Lm7Hetfp//nU76nGtMoQShyVKtKgRJLAM+oMvOGw9+hpTQjpAj8/kHn
BEQ0olr7ExkNLo5UUWX5BMy+US3yS9Dreln+yStjwIy8rUHMN2W2uGXlTB/ZLBx3X6RHG4MEaJLt
z8n8rrgBYCxQk6WUDQw88cNcfKZVNHaPEt6NxB39iIHtpsLsfB2qrs9Qt5SYfmKUbyKuGyxkRw4V
pKmQOsjoIWljOzCWIIWF6doJSE+MIXHmFWfmSHuXb0ByBNMXvM7QWYlLjDMRh/cGlasBpg9V/31A
CjKhK8RMkrydj9/90LTPSU2OEw8szSbZeaDGBZ5PHAffhq0QBtpoll+dni1YoA/TTPPCKI6N/b6g
1d/+ck5SCpspIMfFIJvGMNpPv9r68NpHo2X6hAIABiAhmVKyVWC01qfDCt/aGIdhcCNfx068C4li
Y3rq4b7D7VD3h8E+6q8QteXlNjv5/H5U1rITV3MzRPqJq3ePvqn2uTf5KuVASTGQ75OyZ572KXoE
RXb9zJhAFYIau6/wTJkgHZwUhbQdA7BXPR5BezG+j/sZS4ekHd57Xf9+o+qTchkAjUsEFKxmjhmb
4qDmOR/3grwsG8qY4h//9BdC29cWhd++2UPxZnkJoSRDkYw6x3qUSpILWmDzgolu9Zq3We5OBZdW
QxnxBhz0ULboFIlLTzDfrp6znPASk7Gaqhubls5snQTvhtrV6XGx2YtblaTdlWaG8cQVK5k5B/Nt
N9E4+hzEvVlr5Zh4W2T3GKwLWB5lo2HUjKTcvHz9ulRk7Jkj1zdRpOYnrNmczJjez8qs52Nu4o5S
E/aAhKZl9v1w/NstoBRfdVsHq1L9HhTTBPtpynMU9ZmtdHrDLQ8ovEY40DyeX4f6L+cRfJN8ceSW
SzPar/0uyzRnoO9sypVe51bKoXypJLqM9Id7L9MG1tuXz14q7x0jx4T0ZDMQodFQmh+BQ8eaqLrP
edqfiy3kWJEPNyvr6T/ZxcbfFZ7yMfTQ3N/Rg2OZlnhnmeExxa40zVQAZgyxLgHoja0H57mOaAYC
Nxd8AEwR8i4wOpGneHeXHE3Ckoho47R9n7VmKTrVOalCKki6lL+M2xXpf5wDp1Ab6lFb9cC4oC6y
0ZaVOqMD3ET5AquxTVD6692xk9+stJo7iu7EHIenxbm9De4RoqEyMrbc9MEWK7w0FlYVvUesh8ce
Goo3NF+9NWE2cnnu3pMGCPcuah7IFlfnCirW+OWuNyHbdHmO9rpUy9mj1OCa3exbVxpuiDPuikm2
p4DMpbUMuNITGvgAT2owJhGFBWRfZmDhT8WuCfGCX0V0cSljZ6UoiswaDwgNiXjge58m2/k2BfYD
seN/VBmCBW9rXF8TtHQoIzOVALPxalgMzJJQq5LXPAHw4PFcpbMFw7sJYkNsKsnDRmcv8DMejpk2
jM56lgJbiLWySsi9NobTgutnzvp6SQiKOCemWShzZk3I991QeCNQaQcoLO7tGnuw/32ADyIBdAPT
7sJr2Ri2eojxUul4l8juGAZzX0i4MzaXMYukjCO7xd+8MXXTOP04PUOBVkvk5y+AkukvxlzFTYD+
ZtQKBYm6cutMyHXV7/+9zLB6lvjGPhQJiUMqLDLGFSLP/evVJHhYBYmcrMceZOHYZy4HeOMd3hQa
aMrFFv79uNFl/88BapxpPUuoYO0Hs1jb55S6yvfFfv3XFs1CgTes/93NAIv7A8nK0zMgONSxPirt
uyGNz2B5zPdoBDvyf3j5f2OGWF6esfPhoBlKVmoZSTC1hyyMEkay6beZP2rq406lVippbx5+cLTP
IVueUdltOEiqeArWpepPPkvTut576fu0V4GhoH+/GNe3zoBZgZCfn7v2x0E0Tin5/YvSuou85QBa
7PfNhdOOpGaG8c8cYd5twWnzBQOL7zBHPIjp7KMiLEGVCYmnAVMhcsEIzo71T3HPjYEzimTPYrNm
ExSD1Yf4PgRuNuXn2TDkamdiaccPn7dOR8dHZoJyv9f2P9KI/OlIrmb+uxu8gBkrRJFqEtb84lbS
hB+ZqeccuDt1xIsdCfLpjO92IsCmrdLC4X6PXFinZIsePbbTPj/UpHgblizTzlC27/5/PFp4alAt
PV8Py/kTNxLDJOIVc0WwlP72E/0btpvHoIySNKODj29vTk+aPp1KNaR1PHeMFXsVqkEiXLhDKjAu
fEZ0Q8Uycndk8gn3u4zHlSzQT0KLTXvoXazHvk6F/K8Ni7HZpGm6bQtczUiN3cn7UeXBJdlDGlor
YH5VOBu5dQBQJ0Q8900tbP9410kB0jx++sxtuRkpDY6PDf1Ed4hVnKvuwMAAWv5tBySOt0isreGi
eC9hxKgntqpUxDElZbm/mvSJIyn5M+/iHXQtFHMb2qmyAJkBbxJAyuN8dvcubslf0i2at31f1/V+
K85WIArzHVG7UcCGrPJB6YS05EVT17y93kMUWZE97cGpkUvKNpbfEdIKkWY+MwnR198HQ/NjQXJa
g/UKVi2XzrogTpEpkvC7WNzUsCzX/3QxAEfC90+g9X2E+VEJAjkPh50yvU04GgvDEEBh/J8kdkEE
VbTKwnaLgtfxetmq4n66L18sYEnd3FZnDGt/jQRzwYREAqmY2thzksiKXi1Ptc6tmpL3zvzpaXxa
uxALWVfr9VdvkN/576xdp0bOCMkLxRT+vNooO7Jf/LCFuB1qD7IA0ckycILk6Yozto9YcK/Robis
F6deTzAeL3CCY7doAyt5E4Lk7cckaf/77RivsUOdQWqcT7s7mEkxEexYSfMIX5ghPUKdqDW2TJOM
HeTDQThpjICmJ34ib01xv+s7cHYxLmD77BXKT0RB0R/kYM4OtJEOLcjMYzi7RXX5NzkqlkbSRD50
7utJcmIkT9v/Q61QrOrM8UKEBvOFfaVuNIOugK03iZQr9atfPQEx+ExRbxdKQ8Opvtw9OgO002FH
yuFT6oE3Yjr+YJgXVUvCqHKJ2NRlfXRNWx4OMtZh4qMRfXrySjIzl+BjwuAHxcLhD1r+3vthIwRr
v+5qwa1JdKt+E5O2lhe8zajqdKP4RV9kMAy+LE9V7LTcTd7cy3YQya8K6fVq2cmMsHybPBwD9Lnu
OOs83Eplqv8snjcRHTlHKNH9hGfHUSzWsRezOUMuTAJKjaLlVXYFIbc4aEIUxm0S4fFvLuv6mBVT
471JRiXXyY0HUXs8NA7z0oCV4J2jCCYB5bU8NNfbmYxvFTnvyaFFE9d4Z384R9mwi45FKdfGnEHu
9dRrNUMxUHFxxvzc2jFB6/MomsBRCHRGvkIueLXDZSrJUYm36Zdm66D6IBby18WO+K4lFQ9Imsw2
dvMxEKFwoJrKjJV5qkjg+cIHI1eu7qr56D9ISRHVJ19JFnVhnWgzxjYqgnyikqTnO79adMfRFarl
+s8BvnGhFIObbrab99VUp7CYdAMeSVxvpHKbJV+u7MIm67PztFd3JGXKMLJ5uK/B1f5rF5RTjgSR
C6UyeEDMXdQSii3S5gFlubQ7U4o/OqWnVagv5nqpHwxCbd7n6LutHLkI2J56Fgz4LvlCHqZhUF4g
0V6FBwL/2UyBBRDkVBOILCC7azAqnRuNibJCXcTJdJ4mn5sbD+t4wxaNMPDztbgoYMMkADsVE5/G
QnPQdP4xjFBmICZBFv413IWTXhdeJbsFFhyYfZPEwrU4TD5t0P4q10E1tMrpawmjxI6GKjaWHlz7
IqqoLyVoulY7XHrHjMmZnjwxZsGCJJaeZj/nk0wPFetWpAeJ7o7KID7NS1ddq98AXXILkdiml8Y4
Q+++CRZgfcSIufOtStcu+Ml2Vr2RHyRfdFwKKahcEwwj7tq1geEgS4mEhdv8xw47M40M/KiyUWRk
pJRygyu9ajhAPQJwJ3V49V+2hah8wdWU+nJMdivTHM9MIQZjG1mldcqpfnNyuQ+hKZPaThHdCJzO
F0Fjzqe7ccElWjUUeEjTRM4sHb6EcG0kNhB6VHXQtu32xOFIUfFU5a2vtzWuktQYSBChlQ7hmvf8
sWOo1tHA3ubYuYETPvDEQAkKv0VQgqa0rk7l2YYRJaByxwfhaTEpJ5gMx5n0/i3jo55D/bFfm7DN
n4X73fzdTXU+56FLicelYCEDmazYsfnaze0QlYNlRfEEm/JK9WM8mDYPqt7s3gAKUwYpeguqR/vU
AA8UPyxMQ3zh9g6aoEB/gi2WbuBMevXCmkcOcgdLN/RWEKrrRTzp0+GbUoQ9KPaQJSqprvSxQZAq
sqilHJRnkBItqH+SO11oH71kxuk61eFROvQ0kFT7Gf3+9Dwe2Dm0jah61Bzk+O/LO1QXV1aTWg7I
XK3qyT2bbRgE2T6RbKqqQW/nc/fNBCVEfoh1ki+Ie0OHJoS8feEFX6+F9Xp6LlsOKQiTsH2p5kGG
ZpSkqK+queQtjCWtG8MQ5Y80N/w+Qmx2v5V7OYyAKaq+vFCbzCZzhBtHW3nVnZPL+WOsYG74uRLP
DsRzAS2AXcb5k4cyqXf/nXr8sYUYtfAsWWKt5D+/ZyUEnmGxal5lvU66cunQphcYjWLZtw0LZnts
+sLOZ62GtuqUxznHy0kLnI+fE/2ZDKkB5t3ezmOX4dHqzU9iSahGH2vP2SblCKdzYUAEqBlCK+69
tMMwh8fkKVrSydk4u8iMla5l1p6iz+wPefOEJtoxFGZLd5Cz0qfd0QF6rZ7hUPJRFO8quieGt359
wk12qYd5yZwieO6j2IKHwDgeNp3zkeEy1NtFeEQeL+5h3iWnVhnUghu4EyEJmL5dF/8n8P1vwB6I
Z9Hpy2Sm7LTwb0R3pCnuEk71GDH0zxWglnozLd70NuVoiCCXkrR/At3O8Xs28CyZnKTbBdqN+OqB
hwD3QyWCusNhTAtWP1lDwC+8zawBY/IzAAWoMOagvqWEp38Dt0yWRFaH5Odp7QUyIyizSPnGqd3x
qlzzmuNsxihOZlTtJRZxfpWN/ANbW+GLHIUEMD865TNL8C3WP/bIfA+NhBImXd8ZKO7HekyBcU73
4kHVIUl3zJ21UWKBANm9bZFgbc2kfayAPrZW6JqAL+SIjJr/IdLrkYl6uTW1ImVDhAQotmVbKEhZ
XbRZ408HeH0WtGwXNZapmob98aM/g2n/TuaVQZZkJ94cc5n2sy6mgZXbaOzN2zXTrNVi8hO86oc+
WPbGbcgJBgVHb+GAcCralXFhUUbUHObaqEXvLkJD4a1x8avtyvFGwc7wEeJAcvGaI/TIUdPcxa8q
ZuhsLZ/6a0qQacIC/f2FGOpy18sOyugYDzeUlJTMPxlw/wMvcdiyYXRRh4unCGmG2b8NNO+c6sKr
G54rGsS89ebDVVmOZGMj1s5cmgsTchF7C03qLWXFMGXoo9gfbCwFv1ppkDYlxd6DMfK5xOrSJB0o
Po85UWXvc5z3b4S+thLwAwWpXvP9rKyYRV+b8kXZKEPobWLOhC+hyJaGt6b4aDkVDbTDzZPHv8pm
jQp14W//PkYnlG+6HGFwURe4+DS5j7+glEDPfdONe9Y+mvufWTcQHL7pZXdVEZ1O2bORBFeQFeLW
5cz2te3COPyQe4xEIeq8XVsfU/xOEqrussTze49KyFR10zKcs83CnRHhH5ffLo3maPj2WyFOXvJH
fb/M0LvORIqCmMrZjoS04K423/3G/l+pCMGW2vvfmDXjsMNki2qpHF8WIYGrUhVTC7LydEA9bO4y
oYQIWKUdijm2wmiBDT8tVI1HDnGunprDY2F5pEBw60/uk8JrjOSpRXc6Yih81gqWj4hTgCW8lMBA
CcdQEg2YXcy+K5mTq0wbKlmisy7VwyM75mPPWfYkVSjO0R78LKiTNxdg+nYjSnrZuy0LxajPS4m7
LSFmplfRplIhN9D61lqfb8KecKqiy6hCUJy28DspOpAKDUiM4/SjGgoPHFyCjof7RmF94IwXumpU
iDoI9Xtn3InGkDEsQ8kQHBUkVRzN1Zs6LdCTx06SZXi7vnYAVLQ4fKBz1534p9YvWQwDYZ693rwF
VVbI/x98k5VYSDX9tvc7vEPY1V9tahE11Q0hHmSA8A5AhW2LPxO2vEHgPS5Y8A1zmyUz12kq8M2i
N+NhJRv56kmQjbzBblumFQUfxZd4SjtiIUOr7loYW4RrFRzg7NkA68Cz57EErEEVEWmvMl2YCuUm
xH4tjIeghDNX2Ngx2JB4T+D13/PzL5walcrqU6QvzRErhR7cqnXYdYNA3yOhT2gdGBxG7IQJKnP9
/6cZ5vlYc2eKKXLgurggtkt3ywFZSHo7aDmC9pNAWDRIJAphrQKoKyTHzRUHCrU1OmwFltY0xh4A
4JmJFpYDrRtICch4ROid5CBV6JV74c5G8xR/xXHLcwszGDgoNnPtpIbBadKN0f0mXd+/fKUrdCg+
OxDZk9EKr4veOXB8MUFhvI947yaypJ9UY8ihCl3YHGQFo8ACCL/10ylyZuYI3ZdXFdpjyN29fb/l
Q18zJh8E+TQqZb/tHbcjYT0tvRWxxEwP3o0Myw/qf8sKOo6Q3s7ED0qomcgmA7u5ug6MzqRNjf11
c1XS4nF/QFZFRoGxC6ZfpMMfWskUUmHkV6qmIQoI1BUhulve97tEP4Ww4VuuwtLlzT4YbT2wfR94
LfuXYMsvq5+5px73S80EtiBiugAkojPL9RgngRyACAlDAFWbKi7efqH8C0AaBF5CzynBXWMNZqqO
VuofdnGOfkkQkI1P/1aVV1unQ5L2z7TR8aHp/w+1kr4jEdacFjGkP9ye1y7mixtydGUpcqKbogH7
d8+U5kOEwOtt10Wpz3Tpc4JfEQ0rqL5K1Vdh0DsbXMqTwkhta+5bfRqYPt7o0VXKH2JPfeh23eyc
U0LXt9RK+db/m46L85p0BOTmn/xJgYYQQ3cTXWjQPopTbXBSU7E4p1pnU4iISQSKd2ztYrnr0Od+
/LL5jnDvZHOFPw2dZ9o8tKgMk10fBgJlTBcPdBBTR1i5Ayy5dsbRoZbNw4H42ZLVWKIk95FBifEK
iDxZqSCwUpdRXcC2TPKfwoWAKgUqktaUv3b02eqNLHGTuGV7t/JvXKBS9VaASWIZVNiBt56OSqOQ
gk6aiSq8s4zHXYYC/3dvPbLkngxw8i0shYy8CsiSeosHKgon2ii5E5tCCnHkUZSbzuIdNO3XV3Re
0lKmFjgtDOCghEvpWMtZzbqUyCTi5teLbGm2gzBwr5/ggtuaru+D13FLd8VBLa3LkcD+AcmdmAEM
zLHlEHGGfBTwnhfhbuoVdRPjdoibPWjvBlWnfIxrv+NgFfXuEA6pwM82IVwrE1YuUHcjhuU1lBK3
ASe7+TirhvFbfr8qeIeEcoaxjcbUhxBMlIR0I17u8jSLwPERDP7ZhPJM9N7gv8tJHoOUrAqEhiWS
1rmbKv1PxDj3f02jacmMeRAOxEUzH1pSYnXHMBu1WvL6kzRrmhaYQSQkPuF1Xu/fvyu1TrpWD/p9
G56JB7SiHA2i2GdCWq69QcrMr3khIPbj0+xxOaKrnZdgUSquKuUh5tts2g/18UZRlbjyNjtnyLce
HF7rnATOADA0LHQ3iN7s8koZFjSRajGqn9cmNXx0lBjh3q38HHm+O31XpCKr2vx0fadEUfdDqjSh
bei/8oQVuFeOYAu/ApWyK/kTsnwzz3dHNP/4rAUrwUmWtpZagw+KQxXu6BIg616xv9KbF4X48HIV
FHxIWoLwEs0talvqbdS2RIafg6qO2NiW2oVOZQ/pvYu/i0owWTebGk2FQeFAwB1Gki8nPqqc2aJV
ODnCLsTqA7ObBezclU7fpKGntreqq/HJPIPImsDoCo0jBVocQpvnvEHFvFFnWoZUlZjPjd9QSPDQ
cZTTbYTa7PPFC9Q+IeL0Bz4myayLrzxujDJRWctIf77+5jbUHxJIr0DL1v32AhaqU558h1zxKWsF
fhHz92BeRDd+O/SDyn2H/U3G4QZTO18Y3sIfNiDeqxzZS+efTMI8pNTqBdDN0lQNd3Ul8r3EDkou
d03PWZpwa4NLJNQhuKeB95P2ac8pWg/t93FX665mVKUyQuLwj+TI+J1LNKfIVGDqMswWTvCCPAS3
BYEDMrmJ7sJW49bH6w+Gr61MywA821QxCLmxfxvQp01+FoE/Dv5tC6t6wUgTvOaX0VzfPTKXfiXw
bU04jqSrIbIXbUsTXoF7Gnby9xb1BQKgO4h2dT/A6sg1+qzPvHt7lYkMn9LAwPCII5K1kl3FYGmW
+Y9zLt9tFAI9t3Vrd6QLYQEjnd0iJZuKIN4lL9V1MQYUzEhCrS3i6QPfnD8Hnug3Mjq9EIP8xU2r
Td+FVdQmdYOAjYAYTmCDGSsLgRA2vrpX4vWJhdk0mZoCBDM7Sy+gPdCcXPB3xgdlZ2nhT6VKjcDi
Xs06fSzh5uxP+0UCWj+HPzzilt+B70ivAFSj0oTUQbXIPAj3tmluW0k5d7mC/p5EsA6jROG98K6t
pR+MlKQ0P6BN76iWt1lhVJhW7HOGdrND/dRbmJhqRhFA6P0FTEvV1iASG9w/xMApRoUz5vAtUPO5
mUD/l6Nuxy2qPNXMqABTRlzDP/c7PoexGpMcGMvbQG+ntp1D1oEyx50F4Vee23VGKPz7KjN12peG
qppAkHdN/dwi2QmwBg80yEi/uxX92O6SvUB8xUbYDzvE5ykcWH0cENjS7yImI+FvoTOWiByzuRVM
E5MUxNNg5tU32taw6GIht193q2PBxRTQSfV3cIG6/9mKHW8JK8EmOw1AAeWiQVbz1lwV3987Mm56
CXaOXaVdR7JuitQ4PK+5afgMCUr8FrEVlZW9cRTSGbuxi29DS5aW5+EagNH/+umOy3LSKX3P78ZJ
UbiFZyV9Rs8fjP4/5VqTWuX2UW5Shn1QcOyaxEVl7GGJjJwKJ8a8aKt2U3/aXJEuaIFzxfM1ug42
9WN/d3usvJeUKDWgOptd7A1xHur6VAGaxxOgDoplCDrs5KmNycJzFI83tBzjh676NX8/xdYyrV9r
h2swjYrrl7b+XHnsrFD9CCup8eovI5ScWV9IxP8zcbHywHZcTx+8Pe7clJ/GkhGcFVzy9TFIVAkX
OI7+TcV7ra5E2i7FmLUJJ2Xax9TJPP0TkEdzXu2/qWogzUMY0DSz1HlCG3wIymbzyj/uaKFINPB3
WmOw0kdBoshfiS+6wuJIwePhFQnCADU3tAiQDCaETaNBzAI83KWCPZ2EN3TZd+bJ/177MAqMoLAa
x7KIryJwRcQdYZvKsc4WBK8dfILXhAaFe3g9OpwA8ZiJPBiBeCq5WW2dBL+yDxnoknuoAhmnyqNY
t8MkpJreXX9VRh3k7KWlWObHoQqgl1Gpl0L5HXsfjby9tKdWTao0scjAKzu109DQYWwOmvM43UH1
7PHDh5K5lmEzY4XsEALEUgmTy+2uGjPLW5k8JRhPZV/4VAcWXpUy+zvasNlimgNIzk8e83odFZ/3
1KS5QQyrHJJx7bAC1wP2I0IzJ9zUV9dcqqaXEVBV9ix5gAtWWfbgIGwEfCW0L2CYhtIWh219Coqc
MoChJSLS7F6QQLVR4AIgYbtvRAPgmhUjPZrGQqWzVPdy86RCcNZuOu534OYLIY5Tgq4lbqvdUMdA
ucPy+6bFiA==
`pragma protect end_protected
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
