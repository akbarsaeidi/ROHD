//set MAX_SIZE
module HV_gen2 #(parameter SIMD=32, MAX_HDC_LEN= 64 , MAX_S_SIZE = 7 )(
    input logic Clk,
    input logic Rst_n,
    input logic [ MAX_S_SIZE-1 : 0 ] Sn,
    input logic [2:0 ] b_vec_sel,
    input logic data_valid,
    input logic [$clog2(MAX_HDC_LEN/SIMD)-1 : 0 ] counter,
    output logic [ SIMD - 1 : 0 ] HV_out,
    output logic out_valid
);
    localparam F_NO = MAX_HDC_LEN/8;
    localparam LOOP_MAX = $clog2(F_NO);
    logic [F_NO -1 :0 ] F_vec; 
    localparam logic [7:0] b_vec [0:15] = '{
                            8'b11111111,
                            8'b01010101,
                            8'b00110011,
                            8'b10011001,
                            8'b00001111,
                            8'b10100101,
                            8'b11000011,
                            8'b01101001,
                            8'b00000000,
                            8'b10101010,
                            8'b11001100,
                            8'b01100110,
                            8'b11110000,
                            8'b01011010,
                            8'b00111100,
                            8'b10010110
                            };

always_comb begin
F_vec =0;
    if(out_valid)
        begin
        for (int i = 0; i < LOOP_MAX; ++i) begin
            int k = 0;
            for (int j = (1 << i); j < (1 << (i + 1)); ++j) begin
                if (k == 0)
                    F_vec[j] = Sn[i];
                else
                    F_vec[j] = F_vec[1 << i] + F_vec[k];
                k += 1;
            end
        end
        end
end
always_comb
    begin
 
        HV_out =0;

    if(out_valid)

            for(int i=0; i< (SIMD/8) ; ++i)
                begin

                    if(F_vec[i+ (counter * (SIMD/8))])
                HV_out[(i*8)+:8] = b_vec[b_vec_sel+8];
                    else
                HV_out[(i*8)+:8] = b_vec[b_vec_sel];
                end
    end
always_ff@(posedge Clk, negedge Rst_n)
    begin
        if(~Rst_n)
            out_valid <=0;    
        else
            out_valid <= data_valid;
    end  
endmodule