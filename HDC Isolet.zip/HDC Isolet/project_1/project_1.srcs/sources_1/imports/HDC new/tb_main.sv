`timescale 1ns/1ps

module tb_HDC_system_top();

    // Parameters (can be matched to your design)
    parameter SIMD = 128;
    parameter HDC_LEN = 1024;
    parameter F_SIZE = 617;
    parameter CLASS_NO = 26;
    parameter PERM_EN = 0;
    // Clock and reset
    logic Clk;
    logic Rst_n;

    // Outputs from DUT
    logic [$clog2(CLASS_NO)-1:0] decision;
    logic valid_decision;

    // Instantiate DUT
    HDC_system_top #(
        .SIMD(SIMD),
        .HDC_LEN(HDC_LEN),
        .F_SIZE(F_SIZE),
        .CLASS_NO(CLASS_NO),
        .PERM_EN(PERM_EN)
    ) dut (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .decision(decision),
        .valid_decision(valid_decision)
    );

    // Clock generation: 10ns period (100 MHz)
    initial begin
        Clk = 0;
        forever #5 Clk = ~Clk;
    end

    // Reset generation
    initial begin
        Rst_n = 0;
        #20;
        Rst_n = 1;
    end

    // Simulation runtime control
    initial begin
        // Run for enough cycles to observe behavior
        // INSTR_DEPTH = 64 instructions, PC increments every clock
        // Let's run for 150 clock cycles

        #2000;  // 2000 ns = 200 clock cycles at 10 ns period
        $finish;
    end

    // Monitor outputs
    initial begin
        $display("Time\tValid_decision\tDecision");
        forever @(posedge Clk) begin
            if(valid_decision)
                $display("%0t\t%b\t%0d", $time, valid_decision, decision);
        end
    end

endmodule
