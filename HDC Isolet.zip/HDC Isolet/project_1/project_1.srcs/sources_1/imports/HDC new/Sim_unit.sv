module Sim_unit #(parameter WIDTH = 128)(
    input  logic [WIDTH-1:0] op1,
    input  logic [WIDTH-1:0] op2,
    output logic [$clog2(WIDTH):0] out_sim
);



always_comb begin
    out_sim = 0;
    for (int i = 0; i < WIDTH; i++) begin
        out_sim += op1[i] ^ op2[i];
    end
end


endmodule
