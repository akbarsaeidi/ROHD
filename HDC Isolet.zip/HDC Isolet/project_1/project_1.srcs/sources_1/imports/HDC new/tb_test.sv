`timescale 1ns/1ps

module HDC_main_L_tb;
    // Updated Test Parameters
    parameter SIMD = 128;
    parameter HDC_LEN = 1024;
    parameter F_SIZE = 617;
    parameter CLASS_NO = 26;
    // DUT Inputs
    logic Clk;
    logic Rst_n;
    logic data_valid;
    logic [31:0] instr;

    // DUT Outputs
    logic [$clog2(CLASS_NO)-1:0] decision;
    logic valid_decision;

    // Instruction Memory
    logic [31:0] instr_mem [0:1023];
    int instr_count = 0;
    // DUT Instance
    HDC_main_L #(
        .SIMD(SIMD),
        .HDC_LEN(HDC_LEN),
        .F_SIZE(F_SIZE),
        .CLASS_NO(CLASS_NO)
    ) dut (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .data_valid(data_valid),
        .instr(instr),
        .decision(decision),
        .valid_decision(valid_decision)
    );

    // Clock Generation
    initial Clk = 0;
    always #5 Clk = ~Clk; // 100 MHz clock

    // Main Test Sequence
    initial begin
        // Reset and defaults
        Rst_n = 0;
        data_valid = 0;
        instr = 32'd0;

        // Load instructions from memory file
        $readmemb("output_instructions.mem", instr_mem);

        // Count valid instructions
        instr_count = 0;
        while (instr_count < 1024 && instr_mem[instr_count] !== 32'bx)
            instr_count++;

        $display("✅ Loaded %0d instructions", instr_count);

        // Reset sequence
        repeat(4) @(posedge Clk);
        Rst_n = 1;

        // Feed instructions 64 times
        for (int repeat_idx = 0; repeat_idx < (HDC_LEN/SIMD); repeat_idx++) begin
            $display("🔁 Iteration %0d", repeat_idx + 1);
            for (int i = 0; i < instr_count; i++) begin
                @(negedge Clk);
                instr = instr_mem[i];
                data_valid = 1;
                @(negedge Clk);
                data_valid = 0;
            end
        end

        // Wait for classification result
        repeat(20) @(posedge Clk);

        if (valid_decision)
            $display("✅ Classification result: Class = %0d", decision);
        else
            $display("❌ No valid classification output received.");

        $finish;
    end

endmodule
