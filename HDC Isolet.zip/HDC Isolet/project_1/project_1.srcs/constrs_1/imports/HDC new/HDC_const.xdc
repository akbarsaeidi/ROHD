create_clock -period 10.000 -name Clk -waveform {0.000 5.000} [get_ports Clk]

set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets Clk_IBUF]




set_property PACKAGE_PIN E19 [get_ports clk_p]
set_property PACKAGE_PIN E18 [get_ports clk_n]
create_clock -name sys_clk -period 10.000 [get_ports clk_p]



