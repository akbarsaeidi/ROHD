transcript off
onbreak {quit -force}
onerror {quit -force}
transcript on

vlib work
vlib activehdl/xpm
vlib activehdl/blk_mem_gen_v8_4_11
vlib activehdl/xil_defaultlib

vmap xpm activehdl/xpm
vmap blk_mem_gen_v8_4_11 activehdl/blk_mem_gen_v8_4_11
vmap xil_defaultlib activehdl/xil_defaultlib

vlog -work xpm  -sv2k12 "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" -l xpm -l blk_mem_gen_v8_4_11 -l xil_defaultlib \
"C:/Xilinx/2025.1/Vivado/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm -93  \
"C:/Xilinx/2025.1/Vivado/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work blk_mem_gen_v8_4_11  -v2k5 "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" -l xpm -l blk_mem_gen_v8_4_11 -l xil_defaultlib \
"../../ipstatic/simulation/blk_mem_gen_v8_4.v" \

vlog -work xil_defaultlib  -v2k5 "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" -l xpm -l blk_mem_gen_v8_4_11 -l xil_defaultlib \
"../../../project_1.gen/sources_1/ip/blk_mem_gen_1/sim/blk_mem_gen_1.v" \
"../../../project_1.gen/sources_1/ip/blk_mem_gen_0/sim/blk_mem_gen_0.v" \

vlog -work xil_defaultlib  -sv2k12 "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" -l xpm -l blk_mem_gen_v8_4_11 -l xil_defaultlib \
"../../../project_1.srcs/sources_1/imports/HDC new/FSM_HDC.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/HDC_main_L.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/HV_gen2.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/Sim_unit.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/Therm.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/class_unit.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/main.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/tb_main.sv" \

vlog -work xil_defaultlib \
"glbl.v"

