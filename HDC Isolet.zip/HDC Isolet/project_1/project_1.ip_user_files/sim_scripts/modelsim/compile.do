vlib modelsim_lib/work
vlib modelsim_lib/msim

vlib modelsim_lib/msim/xpm
vlib modelsim_lib/msim/blk_mem_gen_v8_4_11
vlib modelsim_lib/msim/xil_defaultlib

vmap xpm modelsim_lib/msim/xpm
vmap blk_mem_gen_v8_4_11 modelsim_lib/msim/blk_mem_gen_v8_4_11
vmap xil_defaultlib modelsim_lib/msim/xil_defaultlib

vlog -work xpm  -incr -mfcu  -sv "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" \
"C:/Xilinx/2025.1/Vivado/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \

vcom -work xpm  -93  \
"C:/Xilinx/2025.1/Vivado/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work blk_mem_gen_v8_4_11  -incr -mfcu  "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" \
"../../ipstatic/simulation/blk_mem_gen_v8_4.v" \

vlog -work xil_defaultlib  -incr -mfcu  "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" \
"../../../project_1.gen/sources_1/ip/blk_mem_gen_1/sim/blk_mem_gen_1.v" \
"../../../project_1.gen/sources_1/ip/blk_mem_gen_0/sim/blk_mem_gen_0.v" \

vlog -work xil_defaultlib  -incr -mfcu  -sv "+incdir+../../../../../../../Xilinx/2025.1/Vivado/data/rsb/busdef" "+incdir+../../ipstatic" \
"../../../project_1.srcs/sources_1/imports/HDC new/FSM_HDC.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/HDC_main_L.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/HV_gen2.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/Sim_unit.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/Therm.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/class_unit.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/main.sv" \
"../../../project_1.srcs/sources_1/imports/HDC new/tb_main.sv" \

vlog -work xil_defaultlib \
"glbl.v"

