module HDC_system_top #(
    parameter SIMD = 128, 
    parameter HDC_LEN = 1024, 
    parameter F_SIZE = 64, 
    parameter CLASS_NO = 10, 
    parameter PERM_EN = 0
)(
    input logic Clk,
    input logic Rst_n,
    
    output logic [$clog2(CLASS_NO)-1:0] decision,
    output logic valid_decision
);

    localparam INSTR_WIDTH = 32;
    localparam INSTR_DEPTH = 128; 
    localparam PC_WIDTH = $clog2(INSTR_DEPTH);

    logic [PC_WIDTH-1:0] pc;
    logic [INSTR_WIDTH-1:0] instr;
    logic instr_valid;

    logic [$clog2(CLASS_NO)-1:0] decision_qt;

    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n)
                    decision <= 0;

            
            else if(valid_decision)
                    decision <= decision_qt;



        end


    /////////////////////////////////////////////////////////////
    // BRAM: Instruction Memory (Read-only)
    /////////////////////////////////////////////////////////////
    logic [INSTR_WIDTH-1:0] bram_q;

    blk_mem_gen_0 instr_mem (
        .clka(Clk),
        .ena(1'b1),
        .addra(pc),
        .douta(bram_q)
    );




    FSM_HDC #(INSTR_DEPTH) fsm(
        .Clk(Clk),
        .Rst_n(Rst_n),
        .valid(1'b1),

        .pc(pc),
        .HDC_valid(instr_valid)
    );


    assign instr = bram_q;

    /////////////////////////////////////////////////////////////
    // HDC Core Instance
    /////////////////////////////////////////////////////////////
    HDC_main_L #(
        .SIMD(SIMD),
        .HDC_LEN(HDC_LEN),
        .F_SIZE(F_SIZE),
        .CLASS_NO(CLASS_NO),
        .PERM_EN(PERM_EN)
    ) hdc_core (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .data_valid(instr_valid),
        .instr(instr),
        .decision(decision_qt),
        .valid_decision(valid_decision)
    );

endmodule
