module Sim_unit_opt #(
    parameter WIDTH = 32,
    parameter STAGES = $clog2(WIDTH)
)(
    input  logic clk,
    input  logic rst_n,
    input  logic data_valid,  // Input valid signal
    input  logic [WIDTH-1:0] op1,
    input  logic [WIDTH-1:0] op2,
    output logic [$clog2(WIDTH+1)-1:0] out_sim,
    output logic out_valid
);

    // XOR result
    logic [WIDTH-1:0] xor_result;
    logic [$clog2(WIDTH+1)-1:0] stage_data [STAGES:0][WIDTH-1:0];
    integer i, j;

    // Pipeline valid shift register
    logic [STAGES+1:0] valid_pipeline;

    // Stage 0: XOR input vectors
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            xor_result <= '0;
        else if (data_valid)
            xor_result <= op1 ^ op2;
    end

    // Stage 0: initialize adder tree base with xor bits (0 or 1)
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i < WIDTH; i++)
                stage_data[0][i] <= '0;
        end else if (data_valid) begin
            for (i = 0; i < WIDTH; i++)
                stage_data[0][i] <= xor_result[i];
        end
    end

    // Generate pipelined adder tree stages
    genvar s;
    generate
        for (s = 1; s <= STAGES; s = s + 1) begin : pipeline_stage
            localparam int ITEMS = (WIDTH + (1 << s) - 1) >> s;

            always_ff @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    for (j = 0; j < ITEMS; j++)
                        stage_data[s][j] <= '0;
                end else begin
                    for (j = 0; j < ITEMS; j++) begin
                        if (2*j+1 < (WIDTH >> (s - 1)))
                            stage_data[s][j] <= stage_data[s-1][2*j] + stage_data[s-1][2*j+1];
                        else
                            stage_data[s][j] <= stage_data[s-1][2*j]; // odd carry forward
                    end
                end
            end
        end
    endgenerate

    // Output stage
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            out_sim <= '0;
        else
            out_sim <= stage_data[STAGES][0];
    end

    // Shift valid through pipeline
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            valid_pipeline <= '0;
        else
            valid_pipeline <= {valid_pipeline[STAGES:0], data_valid};
    end



    always_ff@(posedge clk, negedge rst_n)
        if(~rst_n)
            out_valid <= 0;
        else
            out_valid <= valid_pipeline[STAGES];

endmodule
