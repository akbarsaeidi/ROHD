`timescale 1ns/1ps

module Therm_unit_tb;

  // Parameters
  localparam SIMD = 128;
  localparam MAX_HDC_LEN = 1024;
  localparam MAX_S_SIZE = 7;
  localparam CLK_PERIOD = 10;

  // DUT I/Os
  logic Clk;
  logic Rst_n;
  logic [MAX_S_SIZE-1:0] Sn;
  logic [2:0] b_vec_sel;
  logic data_valid;
  logic [$clog2(MAX_HDC_LEN/SIMD)-1:0] counter;
  logic [SIMD-1:0] HV_out;
  logic out_valid;

  // DUT Instance
  Therm_unit #(
    .SIMD(SIMD),
    .MAX_HDC_LEN(MAX_HDC_LEN),
    .MAX_S_SIZE(MAX_S_SIZE)
  ) dut (
    .Clk(Clk),
    .Rst_n(Rst_n),
    .Sn(Sn),
    .b_vec_sel(b_vec_sel),
    .data_valid(data_valid),
    .counter(counter),
    .HV_out(HV_out),
    .out_valid(out_valid)
  );

  // Clock Generation
  always #(CLK_PERIOD/2) Clk = ~Clk;

  // Test Sequence
  initial begin
    $display("Starting Therm_unit testbench...");
    Clk = 0;
    Rst_n = 0;
    Sn = 0;
    b_vec_sel = 3'b000;
    data_valid = 0;
    counter = 0;

    // Reset pulse
    #20;
    Rst_n = 1;

    // Test case 1
    @(posedge Clk);
    Sn = 0;                   // Thermometer threshold
    counter = 0;
    data_valid = 1;

    @(posedge Clk);
    data_valid = 0;

    wait(out_valid);
    $display("Time: %0t | Sn=%0d | counter=%0d | HV_out=0x%h", $time, Sn, counter, HV_out);

    // Test case 2
    repeat(2) @(posedge Clk);
    Sn = 2;
    // counter = 1;
    data_valid = 1;

    wait(out_valid);
    $display("Time: %0t | Sn=%0d | counter=%0d | HV_out=0x%h", $time, Sn, counter, HV_out);

    // Test case 3
    repeat(2) @(posedge Clk);
    Sn = 7;
    counter = 0;
    data_valid = 1;

    @(posedge Clk);
    data_valid = 0;

    wait(out_valid);
    $display("Time: %0t | Sn=%0d | counter=%0d | HV_out=0x%h", $time, Sn, counter, HV_out);

    // End of simulation
    repeat(5) @(posedge Clk);
    $display("Testbench complete.");
    $finish;
  end

endmodule
