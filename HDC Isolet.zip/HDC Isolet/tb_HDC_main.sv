`timescale 1ns/1ps

module HDC_main_L_tb;

    // Test Parameters
    parameter SIMD = 32;
    parameter HDC_LEN = 64;
    parameter F_SIZE = 8;
    parameter CLASS_NO = 4;

    // DUT Inputs
    logic Clk;
    logic Rst_n;
    logic data_valid;
    logic [31:0] instr;

    // DUT Outputs
    logic [$clog2(CLASS_NO)-1:0] decision;
    logic valid_decision;

    // Instantiate DUT
    HDC_main_L #(
        .SIMD(SIMD),
        .HDC_LEN(HDC_LEN),
        .F_SIZE(F_SIZE),
        .CLASS_NO(CLASS_NO)
    ) dut (
        .Clk(Clk),
        .Rst_n(Rst_n),
        .data_valid(data_valid),
        .instr(instr),
        .decision(decision),
        .valid_decision(valid_decision)
    );

    // Clock generation (100 MHz)
    initial Clk = 0;
    always #5 Clk = ~Clk;

    // Constants
    localparam COUNT_PARAM = $clog2(HDC_LEN / SIMD); // = log2(2) = 1

    // Task: generate 32-bit encoded instruction
    function [31:0] encode_instr(input [6:0] sn1, input [2:0] b1, input [6:0] sn2, input [2:0] b2);
        logic [31:0] instr_temp;
        begin
            instr_temp = 0;
            instr_temp[6:0]   = 7'b1111111; // opcode
            instr_temp[12 +: COUNT_PARAM] = sn1[0 +: COUNT_PARAM];  // fit Sn1
            instr_temp[19 +: 3] = b1;
            instr_temp[22 +: COUNT_PARAM] = sn2[0 +: COUNT_PARAM];  // fit Sn2
            instr_temp[31 -: 3] = b2;
            return instr_temp;
        end
    endfunction

    // Task: apply one valid encoded instruction
    task apply_instr(input [6:0] sn1, input [2:0] b1, input [6:0] sn2, input [2:0] b2);
        begin
            instr = encode_instr(sn1, b1, sn2, b2);
            data_valid = 1;
            // @(posedge Clk);
            // data_valid = 0;
        end
    endtask

    // Main Test Sequence
    initial begin
        // Initial values
        Rst_n = 0;
        data_valid = 0;
        instr = 0;

        // Reset
        repeat(4) @(posedge Clk);
        Rst_n = 1;
        // @(posedge Clk);
        @(negedge Clk);
        apply_instr($urandom_range(0, 1), $urandom_range(0, 7), $urandom_range(0, 1), $urandom_range(0, 7));
                
        @(posedge Clk);


        // Apply F_SIZE samples to trigger bundling/classification
        for (int i = 0; i < F_SIZE*2 -1 ; i++) begin
            @(posedge Clk);
            apply_instr($urandom_range(0, 1), $urandom_range(0, 7), $urandom_range(0, 1), $urandom_range(0, 7));
            // @(posedge Clk); // slight gap
        end

        // Wait for classification to complete
        repeat(20) @(posedge Clk);

        if (valid_decision)
            $display("✅ Classification result: Class = %0d", decision);
        else
            $display("❌ No valid classification output received.");

        $finish;
    end

endmodule
