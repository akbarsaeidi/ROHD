module FSM_HDC #(SIMD=32, HDC_LEN = 64, INSTR_DEPTH = 64 )(
    input logic Clk, 
    input logic Rst_n,
    input logic valid,

    output logic [$clog2(INSTR_DEPTH)-1 : 0 ] pc,
    output logic HDC_valid

);
    


localparam IDLE = 0;
localparam SETUP = 1;
localparam TRANSFER = 2;
localparam delay = 0;

logic [1:0] P_state;
logic [1:0] N_state;
logic [$clog2(delay) : 0] counter;
logic [$clog2(HDC_LEN/SIMD)-1 : 0 ] counter_2;


always_ff@(posedge Clk, negedge Rst_n)
    begin

        if(~Rst_n | P_state== IDLE)
                counter <=0;
        
        else if(valid & counter < delay)
            counter<= counter+1;

            

    end

always_ff@(posedge Clk, negedge Rst_n)
    begin

        if(~Rst_n)
            P_state<=0;

        else
            P_state <= N_state;

    end

always_ff@(posedge Clk, negedge Rst_n)
    begin

        if(~Rst_n)
            counter_2 <=0;
        else if( pc == 64 -1)
            counter_2 <= ( counter_2 == ( HDC_LEN/SIMD -1) )? 0: counter_2 +1; 

    end

//////////////////////////////////////
//////// PC Logic ///////////////////
////////////////////////////////////
    
    
    always_ff @(posedge Clk, negedge Rst_n)
    begin
    
        if (!Rst_n | pc == 64-1)
            pc <= 0;

        else if(valid)
            pc <= pc + 1;
    end


always_comb
    begin
    
    HDC_valid = (P_state == TRANSFER);


    case(P_state)
        
    IDLE: N_state = (valid) ? SETUP:IDLE;

    SETUP: N_state = (counter == delay) ? TRANSFER : SETUP;

    TRANSFER: N_state = ( counter_2 != (HDC_LEN/SIMD -1) ) ? TRANSFER : IDLE;

    default: N_state = IDLE;


    endcase

    end






endmodule