create_clock -period 14.6 -name Clk [get_ports Clk]

set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets Clk_IBUF]


set_property PACKAGE_PIN U16 [get_ports {decision[0]}]
set_property PACKAGE_PIN E19 [get_ports {decision[1]}]
set_property PACKAGE_PIN U19 [get_ports {decision[2]}]
set_property PACKAGE_PIN V19 [get_ports {decision[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {decision[3]}]
set_property IOSTANDARD LVCMOS33 [get_ports {decision[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {decision[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {decision[0]}]
set_property PACKAGE_PIN W5 [get_ports Clk]
set_property PACKAGE_PIN V17 [get_ports Rst_n]
set_property PACKAGE_PIN L1 [get_ports valid_decision]
set_property IOSTANDARD LVCMOS33 [get_ports valid_decision]

set_property IOSTANDARD LVCMOS18 [get_ports Clk]
set_property IOSTANDARD LVCMOS33 [get_ports Rst_n]
