module Therm_unit #(parameter SIMD=32, MAX_HDC_LEN= 64 , MAX_S_SIZE = 7 )(
    input logic Clk,
    input logic Rst_n,
    input logic [ MAX_S_SIZE-1 : 0 ] Sn,
    input logic data_valid,
    input logic [$clog2(MAX_HDC_LEN/SIMD)-1 : 0 ] counter,

    output logic [ SIMD - 1 : 0 ] HV_out,
    output logic out_valid
);


    localparam F_NO = MAX_HDC_LEN/8;
    localparam LOOP_MAX = $clog2(F_NO);
    logic [F_NO -1 :0 ] F_vec; 



always_comb begin

F_vec = 0;

    if(out_valid)

    begin

        for(int i = 0; i < F_NO; ++i )
            begin
                if(i < Sn )
                    F_vec[i] = 1;
                else
                    F_vec[i] = 0;
                
            end

    end


end



always_comb
    begin
 
        HV_out =0;

    if(out_valid)

            for(int i=0; i< (SIMD/8) ; ++i)
                begin

                    if(F_vec[i+ (counter * (SIMD/8))])
                HV_out[(i*8)+:8] = -1;

                    else
                HV_out[(i*8)+:8] = 0;

                end


    end



always_ff@(posedge Clk, negedge Rst_n)
    begin

        if(~Rst_n)
            out_valid <=0;
        
        else
            out_valid <= data_valid;

    end






    
endmodule