module class_unit_opt #(parameter SIMD=128, MAX_HDC_LEN=1024, CLASS_NO=32) 

(
    input logic Clk,
    input logic Rst_n,
    input logic [SIMD-1:0] op1,
    input logic op2_valid,
    input logic [$clog2(MAX_HDC_LEN):0] HV_SIZE,

    output logic [$clog2(CLASS_NO)-1:0] decision,
    output logic valid_decision
);

    localparam ITR_COUNT = MAX_HDC_LEN / SIMD;
    localparam SIM_WIDTH = 64;





    // (* ram_style = "block" *) logic [SIMD-1:0] Prototype_flat [ $unsigned(CLASS_NO * ITR_COUNT) ];
    (* ram_style = "block" *) logic [$clog2(MAX_HDC_LEN) : 0] Distance_db [CLASS_NO] ;

 
    logic [$clog2(MAX_HDC_LEN)-1:0] Hamming_dist;
    logic [$clog2(MAX_HDC_LEN)-1:0] Hamming_dist_q;
    logic [$clog2(MAX_HDC_LEN)-1:0] Hamming_dist2;
    logic [$clog2(ITR_COUNT)-1 : 0 ] counter;
    logic [$clog2(CLASS_NO)-1 : 0 ] counter_class2;
    logic [$clog2(CLASS_NO)-1 : 0 ] counter_class3;
    logic [$clog2(CLASS_NO)-1 : 0 ] counter_class2_q;
    logic [$clog2(CLASS_NO)-1 : 0 ] counter_class2_qq;
 
 
    logic temp_valid; 
    logic temp_valid_q; 
 
    logic [SIMD-1:0] op2 ;
    logic [$clog2(SIM_WIDTH) : 0] Hamming_dist_temp [SIMD/SIM_WIDTH];
    logic sim_valid [SIMD/SIM_WIDTH];
    logic [$clog2(SIMD):0] Hamming_dist_temp2;
    logic [$clog2(MAX_HDC_LEN)-1 :0] lowest_dist;

    // assign Hamming_dist = Hamming_dist2 + Hamming_dist_temp2;
    assign Hamming_dist = Distance_db[counter_class3] + Hamming_dist_temp2;



    always_ff@(posedge Clk)
        begin

            Hamming_dist_q <= Hamming_dist;

        end

    always_ff@(posedge Clk)
        begin

            if(~Rst_n | valid_decision)
                for(int i=0; i< CLASS_NO; ++i)
                    Distance_db[i] <= 0;
            
            else if(sim_valid[0])
                    Distance_db[counter_class3] <= Hamming_dist;
            

        end
    

    always_ff@(posedge Clk)
        begin
            if(op2_valid | sim_valid[0] )
                Hamming_dist2 <= Distance_db[counter_class3];

        end


    blk_mem_gen_1 class_mem(
        .clka(Clk),
        .ena(1'b1),
        .addra($unsigned (counter_class2*(HV_SIZE/SIMD) + counter) ),
        .douta(op2)

    );
 


    // initial 
    // begin
    
    //     $readmemb("Class_mem.mem", Prototype_flat);
    
    // end






    always_ff @(posedge Clk, negedge Rst_n)
    begin
    
        if (~Rst_n)
        begin
            
            temp_valid <= 0;
            temp_valid_q <= 0;
            counter_class2_q <= 0;
            counter_class2_qq <= 0;

        end
        
        else
        begin
            
            temp_valid <= op2_valid | counter_class2 > 0 ;
            temp_valid_q <= temp_valid;
            counter_class2_q <= counter_class2;
            counter_class2_qq <= counter_class2_q;

        end

    end







    // always_ff @(posedge Clk) begin
    //         if (op2_valid | counter_class2 > 0 ) begin
    //             begin
                
    //                     op2 <= Prototype_flat[ $unsigned (counter_class2*(HV_SIZE/SIMD) + counter) ];
            
    //         end
    //     end
    // end







  ///////////////////////////////////////////////////////////////////
 ////////////// COUNTER BLOCKS /////////////////////////////////////
///////////////////////////////////////////////////////////////////




    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n)
                counter_class2 <= 0;
            
            else if(op2_valid | counter_class2 > 0 )
                counter_class2 <= ( counter_class2 == CLASS_NO - 1 ) ? 0 : counter_class2 + 1;

        end


    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n)
                counter_class3 <= 0;
            
            else if(sim_valid[0])
                counter_class3 <= ( counter_class3 == CLASS_NO - 1 ) ? 0 : counter_class3 + 1;

        end




    always_ff @(posedge Clk, negedge Rst_n)
        begin
        
            if (~Rst_n)
                counter <= 0;

            else if( counter_class2 == CLASS_NO - 1 )
                // counter <= (counter_Sim == SIMD/8 - 1 ) ? (counter == HV_SIZE/SIMD -1 ) ? 0 : counter + 1 : counter ; 
                counter <=  (counter == HV_SIZE/SIMD -1 ) ? 0 : counter + 1; 

        end






  ////////////////////////////////////////////////////////////////
 ///////////////////// HAMMMING DISTANCE CAL ////////////////////
////////////////////////////////////////////////////////////////

    generate
        genvar  i;

        for(i =0; i< (SIMD/SIM_WIDTH); ++i)
        
        begin
        
            Sim_unit_opt #(SIM_WIDTH) SU_inst (

                .clk(Clk),
                .rst_n(Rst_n),
                .data_valid(temp_valid),
                .op1(op1[SIM_WIDTH*i+:SIM_WIDTH]),
                .op2(op2[SIM_WIDTH*i+:SIM_WIDTH]),
                .out_valid(sim_valid[i]),
                .out_sim(Hamming_dist_temp[i])
            );

        end
    
    endgenerate

    


    always_comb begin

        Hamming_dist_temp2 =0;
        for(int i=0; i< SIMD/SIM_WIDTH; ++i)
            Hamming_dist_temp2 += Hamming_dist_temp[i];

    end




  ///////////////////////////////////////////////////////////
 /////////////// DECISION LOGIC  ///////////////////////////
///////////////////////////////////////////////////////////

    // Find minimum Hamming distance and decision


    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n | ~temp_valid_q)
            begin

                lowest_dist <=-1;
                decision <= 0;

            end


            else if(temp_valid_q)

                begin

                    lowest_dist <= ( lowest_dist < Hamming_dist_q ) ? lowest_dist : Hamming_dist_q;
                    decision <= ( lowest_dist < Hamming_dist_q ) ? decision : counter_class2_qq;


                end

        end

    always_ff@(posedge Clk, negedge Rst_n)
        begin

            if(~Rst_n)
                valid_decision <=0;
            
            else 
                valid_decision <= (counter_class2_qq == CLASS_NO-1 ) && temp_valid_q && counter == 0 ;


        end



endmodule
