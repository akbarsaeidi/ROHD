module Sim_unit #(parameter WIDTH = 128)(
    input  logic [WIDTH-1:0] op1,
    input  logic [WIDTH-1:0] op2,
    output logic [$clog2(WIDTH):0] out_sim
);



always_comb begin
    out_sim = 0;
    for (int i = 0; i < WIDTH; i++) begin
        out_sim += op1[i] ^ op2[i];
    end
end


    // logic [$clog2(WIDTH+1)-1:0] sum_array [WIDTH-1:0];
    // logic [WIDTH-1 : 0 ] temp_xor;


    // assign temp_xor = op1 ^ op2;

    // genvar i;

    // generate
    //     for (i = 0; i < WIDTH; i = i + 1) begin : init_loop
    //         assign sum_array[i] = temp_xor[i];
    //     end
    // endgenerate



    // // Reduction tree
    // function automatic [$clog2(WIDTH+1)-1:0] reduce_tree;
    //     input [$clog2(WIDTH+1)-1:0] array [WIDTH-1:0];
    //     integer level, i, step;
    //     logic [$clog2(WIDTH+1)-1:0] temp [WIDTH-1:0];

    //     begin
    //         for (i = 0; i < WIDTH; i = i + 1)
    //             temp[i] = array[i];

    //         step = 1;
    //         while (step < WIDTH) begin
    //             for (i = 0; i < WIDTH; i = i + 2*step) begin
    //                 if (i + step < WIDTH)
    //                     temp[i] = temp[i] + temp[i + step];
    //             end
    //             step = step * 2;
    //         end
    //         reduce_tree = temp[0];
    //     end
    // endfunction



    // always_comb begin

    //     out_sim = reduce_tree(sum_array);

    // end

endmodule
